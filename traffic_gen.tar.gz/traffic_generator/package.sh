#!/bin/bash
#
# Package the Enterprise Network Traffic Generator
# Creates a distributable tarball with all necessary files
#

VERSION="1.0.0"
PACKAGE_NAME="enterprise-traffic-generator-${VERSION}"
BUILD_DIR="/tmp/${PACKAGE_NAME}"

echo "==== Enterprise Network Traffic Generator Packaging Script ===="
echo "Version: ${VERSION}"
echo ""

# Create build directory
echo "Creating build directory..."
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"

# Copy Python files
echo "Copying application files..."
cp traffic_generator.py "${BUILD_DIR}/"
cp email_traffic.py "${BUILD_DIR}/"
cp ftp_traffic.py "${BUILD_DIR}/"
cp dns_traffic.py "${BUILD_DIR}/"
cp web_traffic.py "${BUILD_DIR}/"
cp file_traffic.py "${BUILD_DIR}/"

# Copy utilities
echo "Copying utility scripts..."
cp test_traffic.py "${BUILD_DIR}/"
cp monitor_stats.py "${BUILD_DIR}/"
cp packet_stats.py "${BUILD_DIR}/"

# Copy installation files
echo "Copying installation files..."
cp install.sh "${BUILD_DIR}/"
cp requirements.txt "${BUILD_DIR}/"

# Copy documentation
echo "Copying documentation..."
cp README.md "${BUILD_DIR}/"
cp QUICKSTART.md "${BUILD_DIR}/"
cp PROJECT_OVERVIEW.md "${BUILD_DIR}/"
cp DEPLOYMENT_CHECKLIST.md "${BUILD_DIR}/"
cp WIRESHARK_FILTERS.md "${BUILD_DIR}/"

# Set executable permissions
echo "Setting permissions..."
chmod +x "${BUILD_DIR}/"*.py
chmod +x "${BUILD_DIR}/"*.sh

# Create tarball
echo "Creating tarball..."
cd /tmp
tar -czf "${PACKAGE_NAME}.tar.gz" "${PACKAGE_NAME}/"

# Create checksum
echo "Generating checksum..."
sha256sum "${PACKAGE_NAME}.tar.gz" > "${PACKAGE_NAME}.tar.gz.sha256"

# Display results
echo ""
echo "==== Package Created Successfully ===="
echo ""
echo "Package: /tmp/${PACKAGE_NAME}.tar.gz"
echo "Size: $(du -h /tmp/${PACKAGE_NAME}.tar.gz | cut -f1)"
echo "Checksum: /tmp/${PACKAGE_NAME}.tar.gz.sha256"
echo ""
echo "SHA256: $(cat /tmp/${PACKAGE_NAME}.tar.gz.sha256 | cut -d' ' -f1)"
echo ""
echo "Contents:"
echo "--------"
tar -tzf "/tmp/${PACKAGE_NAME}.tar.gz" | head -20
echo ""
echo "To extract:"
echo "  tar -xzf ${PACKAGE_NAME}.tar.gz"
echo "  cd ${PACKAGE_NAME}"
echo "  sudo ./install.sh"
echo ""
echo "To verify checksum:"
echo "  sha256sum -c ${PACKAGE_NAME}.tar.gz.sha256"
echo ""

# Cleanup build directory
rm -rf "${BUILD_DIR}"

echo "Build directory cleaned up."
echo "Package ready for distribution!"
