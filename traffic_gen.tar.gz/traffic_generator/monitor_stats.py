#!/usr/bin/env python3
"""
Traffic Generator Statistics Monitor
Displays real-time statistics from the traffic generator
"""

import time
import sys
from datetime import datetime


def clear_screen():
    """Clear the terminal screen"""
    print('\033[2J\033[H', end='')


def print_header():
    """Print the statistics header"""
    print("=" * 80)
    print(" " * 20 + "ENTERPRISE NETWORK TRAFFIC GENERATOR")
    print(" " * 30 + "Statistics Dashboard")
    print("=" * 80)
    print()


def print_network_status():
    """Print network configuration"""
    print("NETWORK CONFIGURATION:")
    print("-" * 80)
    print("  Gateway Router:        10.50.161.1")
    print("  Internal Router 1:     172.17.1.40")
    print("  Internal Router 2:     172.18.1.40")
    print()
    print("  Email Server:          172.17.8.10")
    print("  FTP Server:            172.17.8.11")
    print("  DNS Server:            172.17.8.53")
    print("  Web Servers:           172.17.7.80, 172.18.7.80")
    print("  File Server:           172.17.8.20")
    print()


def print_traffic_stats():
    """Print traffic statistics (simulated for now)"""
    print("TRAFFIC STATISTICS:")
    print("-" * 80)
    
    # Time-based activity
    hour = datetime.now().hour
    if 8 <= hour < 17:
        activity_level = "HIGH (Business Hours)"
        multiplier = 1.0
    elif (6 <= hour < 8) or (17 <= hour < 19):
        activity_level = "MEDIUM (Peak Transition)"
        multiplier = 0.5
    else:
        activity_level = "LOW (Off Hours)"
        multiplier = 0.1
    
    print(f"  Current Time:          {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Activity Level:        {activity_level}")
    print(f"  Traffic Multiplier:    {multiplier * 100:.0f}%")
    print()
    
    print("  Protocol               | Generated | Bytes Transferred | Status")
    print("  " + "-" * 76)
    print("  Email (SMTP)           | Simulated | ~1.2 GB/day       | Active")
    print("  FTP Transfers          | Simulated | ~5.5 GB/day       | Active")
    print("  DNS Queries            | Simulated | ~50 MB/day        | Active")
    print("  Web Browsing (HTTP/S)  | Simulated | ~3.8 GB/day       | Active")
    print("  File Shares (SMB)      | Simulated | ~2.1 GB/day       | Active")
    print()


def print_active_subnets():
    """Print active subnet information"""
    print("ACTIVE SUBNETS:")
    print("-" * 80)
    print("  Router 1 Subnets:")
    print("    • Air Network (172.17.4.0/24)          - 10 workstations")
    print("    • Ground Network (172.17.3.0/24)       - 10 workstations")
    print("    • Naval Network (172.17.2.0/24)        - 10 workstations")
    print("    • DMZ Network (172.17.7.0/24)          - Web servers")
    print("    • DC Network (172.17.8.0/24)           - Core servers")
    print()
    print("  Router 2 Subnets:")
    print("    • Interior Network (172.18.2.0/24)     - 10 workstations")
    print("    • Transportation (172.18.3.0/24)       - 10 workstations")
    print("    • Finance Network (172.18.4.0/24)      - 10 workstations")
    print("    • Leadership Network (172.18.8.0/24)   - 10 workstations")
    print("    • DMZ Network (172.18.7.0/24)          - Web servers")
    print()


def print_example_traffic():
    """Print example traffic patterns"""
    print("RECENT TRAFFIC EXAMPLES:")
    print("-" * 80)
    print("  [12:34:15] Email: 172.17.4.105 -> 172.17.8.10 -> 172.18.2.103")
    print("             Subject: 'Weekly Status Report' (2.3 MB attachment)")
    print()
    print("  [12:34:22] DNS Query: 172.18.3.107 -> 172.17.8.53")
    print("             Query: www.microsoft.com -> 10.142.23.89")
    print()
    print("  [12:34:28] HTTP: 172.17.3.104 -> 172.18.7.80")
    print("             URL: intranet.enterprise.local/portal/dashboard + 7 resources")
    print()
    print("  [12:34:35] FTP Upload: 172.18.4.109 -> 172.17.8.11")
    print("             File: Budget-2024.xlsx (15.2 MB)")
    print()
    print("  [12:34:41] SMB Read: 172.17.2.102 -> 172.17.8.20")
    print("             Share: \\\\172.17.8.20\\Department\\report.pdf (3.1 MB)")
    print()


def print_wireshark_tips():
    """Print Wireshark monitoring tips"""
    print("WIRESHARK MONITORING:")
    print("-" * 80)
    print("  Capture traffic with:")
    print("    sudo tcpdump -i any -w traffic.pcap")
    print()
    print("  Useful display filters:")
    print("    ip.src == 172.17.0.0/16 || ip.src == 172.18.0.0/16")
    print("    tcp.port == 25 || tcp.port == 21 || tcp.port == 53")
    print("    http || dns || smtp || ftp")
    print()


def print_footer():
    """Print footer with instructions"""
    print("=" * 80)
    print("  Service Control: sudo systemctl {start|stop|restart|status} traffic-generator")
    print("  View Logs:       sudo journalctl -u traffic-generator -f")
    print("  Press Ctrl+C to exit this monitor")
    print("=" * 80)


def main():
    """Main monitoring loop"""
    try:
        while True:
            clear_screen()
            print_header()
            print_network_status()
            print_traffic_stats()
            print_active_subnets()
            print_example_traffic()
            print_wireshark_tips()
            print_footer()
            
            # Update every 5 seconds
            time.sleep(5)
    
    except KeyboardInterrupt:
        print("\n\nMonitoring stopped.")
        sys.exit(0)


if __name__ == "__main__":
    main()
