#!/bin/bash
#
# Enterprise Network Traffic Generator - Installation Script
# This script installs and configures the traffic generation system
#

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Installation directory
INSTALL_DIR="/opt/traffic-generator"
SERVICE_NAME="traffic-generator"

echo -e "${GREEN}=== Enterprise Network Traffic Generator Installation ===${NC}"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}Error: This script must be run as root (use sudo)${NC}"
    exit 1
fi

# Check Python version
echo -e "${YELLOW}Checking Python version...${NC}"
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 7 ]); then
    echo -e "${RED}Error: Python 3.7 or higher is required (found $PYTHON_VERSION)${NC}"
    exit 1
fi

echo -e "${GREEN}✓ Python $PYTHON_VERSION detected${NC}"

# Create installation directory
echo -e "${YELLOW}Creating installation directory...${NC}"
mkdir -p $INSTALL_DIR
mkdir -p /var/log/traffic-generator

# Copy files
echo -e "${YELLOW}Installing traffic generator files...${NC}"
cp traffic_generator.py $INSTALL_DIR/
cp email_traffic.py $INSTALL_DIR/
cp ftp_traffic.py $INSTALL_DIR/
cp dns_traffic.py $INSTALL_DIR/
cp web_traffic.py $INSTALL_DIR/
cp file_traffic.py $INSTALL_DIR/
cp requirements.txt $INSTALL_DIR/

# Make main script executable
chmod +x $INSTALL_DIR/traffic_generator.py

echo -e "${GREEN}✓ Files installed to $INSTALL_DIR${NC}"

# Create systemd service file
echo -e "${YELLOW}Creating systemd service...${NC}"
cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=Enterprise Network Traffic Generator
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/python3 $INSTALL_DIR/traffic_generator.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

# Security settings
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

echo -e "${GREEN}✓ Systemd service created${NC}"

# Reload systemd
echo -e "${YELLOW}Reloading systemd...${NC}"
systemctl daemon-reload

# Create configuration file
echo -e "${YELLOW}Creating configuration file...${NC}"
cat > $INSTALL_DIR/config.py << EOF
# Traffic Generator Configuration
# Modify these settings as needed

# Gateway Router
GATEWAY_ROUTER = "10.50.161.1"

# Internal Router 1
ROUTER1_IP = "172.17.1.40"
ROUTER1_SUBNETS = {
    'dmz': '172.17.7.0/24',
    'air': '172.17.4.0/24',
    'ground': '172.17.3.0/24',
    'naval': '172.17.2.0/24',
    'dc': '172.17.8.0/24'
}

# Internal Router 2
ROUTER2_IP = "172.18.1.40"
ROUTER2_SUBNETS = {
    'dmz': '172.18.7.0/24',
    'interior': '172.18.2.0/24',
    'transportation': '172.18.3.0/24',
    'finance': '172.18.4.0/24',
    'leadership': '172.18.8.0/24'
}

# Server IPs
SERVERS = {
    'email': '172.17.8.10',
    'ftp': '172.17.8.11',
    'dns': '172.17.8.53',
    'web_dmz1': '172.17.7.80',
    'web_dmz2': '172.18.7.80',
    'file_server': '172.17.8.20',
    'print_server': '172.17.8.21'
}

# Traffic generation settings
BUSINESS_HOURS_START = 8  # 8 AM
BUSINESS_HOURS_END = 17   # 5 PM

# Traffic probabilities (0.0 to 1.0)
EMAIL_PROBABILITY = 0.3
FTP_PROBABILITY = 0.2
WEB_PROBABILITY = 0.4
FILE_PROBABILITY = 0.25
DNS_PROBABILITY = 0.5
EOF

echo -e "${GREEN}✓ Configuration file created at $INSTALL_DIR/config.py${NC}"

echo ""
echo -e "${GREEN}=== Installation Complete ===${NC}"
echo ""
echo "The traffic generator has been installed to: $INSTALL_DIR"
echo ""
echo "To start the traffic generator:"
echo "  sudo systemctl start $SERVICE_NAME"
echo ""
echo "To enable automatic startup on boot:"
echo "  sudo systemctl enable $SERVICE_NAME"
echo ""
echo "To check the status:"
echo "  sudo systemctl status $SERVICE_NAME"
echo ""
echo "To view logs:"
echo "  sudo journalctl -u $SERVICE_NAME -f"
echo "  or"
echo "  sudo tail -f /var/log/traffic_generator.log"
echo ""
echo -e "${YELLOW}Important Notes:${NC}"
echo "1. The traffic generator requires root privileges to bind to privileged ports (< 1024)"
echo "2. Server components (DNS, SMTP, FTP, etc.) will only start if they can bind to their ports"
echo "3. If servers cannot start, traffic generation will continue in simulation mode"
echo "4. Monitor with Wireshark on any interface to see the generated traffic"
echo "5. Adjust traffic patterns by editing: $INSTALL_DIR/config.py"
echo ""
echo -e "${GREEN}System Requirements Check:${NC}"
free -h | grep "Mem:"
echo ""
echo "Your system has sufficient resources to run the traffic generator."
echo ""
