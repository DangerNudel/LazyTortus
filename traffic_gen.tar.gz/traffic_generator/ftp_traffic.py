#!/usr/bin/env python3
"""
FTP Traffic Generator
Simulates FTP file transfer traffic in the enterprise network
"""

import asyncio
import logging
import random
import socket
from typing import Tuple

logger = logging.getLogger(__name__)


class FTPTrafficGenerator:
    """Generate realistic FTP traffic"""
    
    # Common file types transferred via FTP
    FILE_TYPES = {
        'documents': ['report.pdf', 'analysis.docx', 'presentation.pptx', 'data.xlsx'],
        'software': ['update.zip', 'installer.exe', 'package.deb', 'firmware.bin'],
        'backups': ['backup.tar.gz', 'database.sql', 'config.bak', 'archive.zip'],
        'media': ['video.mp4', 'image.png', 'diagram.svg', 'photo.jpg'],
        'data': ['export.csv', 'log.txt', 'metrics.json', 'dataset.dat']
    }
    
    TRANSFER_TYPES = ['upload', 'download', 'list']
    
    def __init__(self, topology):
        self.topology = topology
        self.ftp_server = topology.servers['ftp']
        self.ftp_port = 21
        self.data_port_range = (20000, 20100)  # Passive mode data ports
        
        # Transfer statistics
        self.transfers_completed = 0
        self.bytes_transferred = 0
    
    def _generate_transfer_params(self) -> Tuple[str, str, str, int]:
        """
        Generate FTP transfer parameters
        Returns: (client_ip, transfer_type, filename, file_size)
        """
        client_ip = self.topology.get_random_workstation()
        transfer_type = random.choice(self.TRANSFER_TYPES)
        
        # Select file category and name
        category = random.choice(list(self.FILE_TYPES.keys()))
        filename = random.choice(self.FILE_TYPES[category])
        
        # Generate file size based on type
        if category == 'software':
            file_size = random.randint(10 * 1024 * 1024, 500 * 1024 * 1024)  # 10MB - 500MB
        elif category == 'backups':
            file_size = random.randint(50 * 1024 * 1024, 2 * 1024 * 1024 * 1024)  # 50MB - 2GB
        elif category == 'media':
            file_size = random.randint(5 * 1024 * 1024, 100 * 1024 * 1024)  # 5MB - 100MB
        elif category == 'data':
            file_size = random.randint(1 * 1024 * 1024, 50 * 1024 * 1024)  # 1MB - 50MB
        else:  # documents
            file_size = random.randint(100 * 1024, 10 * 1024 * 1024)  # 100KB - 10MB
        
        return client_ip, transfer_type, filename, file_size
    
    def _create_ftp_commands(self, transfer_type: str, filename: str) -> list:
        """Create FTP command sequence"""
        commands = [
            b"220 FTP Server Ready\r\n",
            b"USER anonymous\r\n",
            b"331 Password required\r\n",
            b"PASS user@enterprise.local\r\n",
            b"230 Login successful\r\n",
            b"SYST\r\n",
            b"215 UNIX Type: L8\r\n",
            b"TYPE I\r\n",  # Binary mode
            b"200 Type set to I\r\n",
            b"PASV\r\n",
            b"227 Entering Passive Mode (172,17,8,11,78,32)\r\n",  # Random passive port
        ]
        
        if transfer_type == 'upload':
            commands.append(f"STOR {filename}\r\n".encode())
            commands.append(b"150 Opening BINARY mode data connection\r\n")
            commands.append(b"226 Transfer complete\r\n")
        elif transfer_type == 'download':
            commands.append(f"RETR {filename}\r\n".encode())
            commands.append(b"150 Opening BINARY mode data connection\r\n")
            commands.append(b"226 Transfer complete\r\n")
        else:  # list
            commands.append(b"LIST\r\n")
            commands.append(b"150 Opening ASCII mode data connection\r\n")
            commands.append(b"226 Directory send OK\r\n")
        
        commands.append(b"QUIT\r\n")
        commands.append(b"221 Goodbye\r\n")
        
        return commands
    
    async def _simulate_data_transfer(self, client_ip: str, file_size: int, 
                                     transfer_type: str) -> bool:
        """Simulate FTP data transfer on data connection"""
        try:
            # Create data connection socket
            data_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            data_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Choose random passive port
            data_port = random.randint(*self.data_port_range)
            
            try:
                # Bind to FTP server IP (data connection from server side in passive mode)
                data_sock.bind((self.ftp_server, data_port))
                data_sock.listen(1)
                data_sock.settimeout(1)
                
                logger.debug(f"FTP data connection listening on {self.ftp_server}:{data_port}")
                
                # In real scenario, client would connect here
                # For simulation, just generate the traffic pattern
                
            except OSError:
                logger.debug(f"Could not bind data port {data_port}, simulating transfer")
            
            # Simulate data transfer timing
            # Transfer rate: ~10-50 MB/s typical for local network
            transfer_rate = random.uniform(10, 50) * 1024 * 1024  # bytes per second
            transfer_time = file_size / transfer_rate
            
            # Simulate chunked transfer
            chunk_size = 8192  # 8KB chunks
            chunks = file_size // chunk_size
            
            for i in range(min(chunks, 10)):  # Limit simulation to 10 chunks
                await asyncio.sleep(0.001)  # Small delay per chunk
            
            data_sock.close()
            return True
            
        except Exception as e:
            logger.debug(f"Data transfer simulation error: {e}")
            return False
    
    async def transfer_file(self):
        """Simulate FTP file transfer"""
        try:
            client_ip, transfer_type, filename, file_size = self._generate_transfer_params()
            
            # Create control connection socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            try:
                # Try to bind to client IP
                sock.bind((client_ip, 0))
            except OSError:
                logger.debug(f"Could not bind to {client_ip}, using default interface")
            
            try:
                # Attempt connection to FTP server
                sock.settimeout(2)
                await asyncio.get_event_loop().sock_connect(sock, (self.ftp_server, self.ftp_port))
                
                # Send FTP commands
                commands = self._create_ftp_commands(transfer_type, filename)
                
                for command in commands:
                    await asyncio.get_event_loop().sock_sendall(sock, command)
                    await asyncio.sleep(0.02)  # Small delay between commands
                
                # Simulate data transfer if not LIST command
                if transfer_type != 'list':
                    await self._simulate_data_transfer(client_ip, file_size, transfer_type)
                    self.bytes_transferred += file_size
                
                self.transfers_completed += 1
                
                size_mb = file_size / (1024 * 1024)
                logger.info(f"FTP {transfer_type}: {client_ip} -> {self.ftp_server} | "
                          f"File: {filename} ({size_mb:.2f}MB)")
                
            except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
                # Server not running - just log the simulated traffic
                logger.debug(f"Simulated FTP {transfer_type}: {client_ip} -> {self.ftp_server}")
                logger.debug(f"  File: {filename}, Size: {file_size/1024/1024:.2f}MB")
                
                self.transfers_completed += 1
                if transfer_type != 'list':
                    self.bytes_transferred += file_size
            
            finally:
                sock.close()
                
        except Exception as e:
            logger.error(f"Error generating FTP traffic: {e}")
    
    async def run_server(self):
        """Run a simple FTP server (optional)"""
        try:
            server = await asyncio.start_server(
                self._handle_ftp_connection,
                self.ftp_server,
                self.ftp_port
            )
            
            logger.info(f"FTP server listening on {self.ftp_server}:{self.ftp_port}")
            
            async with server:
                await server.serve_forever()
                
        except PermissionError:
            logger.warning("Cannot bind to port 21 (requires root). FTP server will not start.")
        except Exception as e:
            logger.error(f"FTP server error: {e}")
    
    async def _handle_ftp_connection(self, reader, writer):
        """Handle incoming FTP connection"""
        addr = writer.get_extra_info('peername')
        logger.debug(f"FTP connection from {addr[0]}")
        
        try:
            # Send greeting
            writer.write(b"220 FTP Server Ready\r\n")
            await writer.drain()
            
            while True:
                data = await reader.read(1024)
                if not data:
                    break
                
                command = data.decode().strip().upper()
                
                if command.startswith('USER'):
                    writer.write(b"331 Password required\r\n")
                elif command.startswith('PASS'):
                    writer.write(b"230 Login successful\r\n")
                elif command == 'SYST':
                    writer.write(b"215 UNIX Type: L8\r\n")
                elif command.startswith('TYPE'):
                    writer.write(b"200 Type set\r\n")
                elif command == 'PASV':
                    writer.write(b"227 Entering Passive Mode (172,17,8,11,78,32)\r\n")
                elif command.startswith('LIST'):
                    writer.write(b"150 Opening ASCII mode data connection\r\n")
                    await asyncio.sleep(0.1)
                    writer.write(b"226 Directory send OK\r\n")
                elif command.startswith('RETR') or command.startswith('STOR'):
                    writer.write(b"150 Opening BINARY mode data connection\r\n")
                    await asyncio.sleep(0.5)  # Simulate transfer
                    writer.write(b"226 Transfer complete\r\n")
                elif command == 'QUIT':
                    writer.write(b"221 Goodbye\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"502 Command not implemented\r\n")
                
                await writer.drain()
        
        except Exception as e:
            logger.error(f"Error handling FTP connection: {e}")
        finally:
            writer.close()
            await writer.wait_closed()
