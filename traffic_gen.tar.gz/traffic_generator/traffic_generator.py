#!/usr/bin/env python3
"""
Enterprise Network Traffic Generator
Simulates realistic enterprise traffic patterns in an isolated lab environment
"""

import asyncio
import logging
import random
import signal
import sys
from datetime import datetime
from typing import Dict, List, Set
import argparse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/var/log/traffic_generator.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class NetworkTopology:
    """Defines the network topology and host assignments"""
    
    def __init__(self):
        self.gateway = "10.50.161.1"
        
        # Internal Router 1 subnets
        self.router1_subnets = {
            'dmz': '172.17.7.0/24',
            'air': '172.17.4.0/24',
            'ground': '172.17.3.0/24',
            'naval': '172.17.2.0/24',
            'dc': '172.17.8.0/24'
        }
        
        # Internal Router 2 subnets
        self.router2_subnets = {
            'dmz': '172.18.7.0/24',
            'interior': '172.18.2.0/24',
            'transportation': '172.18.3.0/24',
            'finance': '172.18.4.0/24',
            'leadership': '172.18.8.0/24'
        }
        
        # Server assignments (in DC and DMZ networks)
        self.servers = {
            'email': '172.17.8.10',      # DC Network
            'ftp': '172.17.8.11',         # DC Network
            'dns': '172.17.8.53',         # DC Network
            'web_dmz1': '172.17.7.80',    # DMZ Network
            'web_dmz2': '172.18.7.80',    # DMZ Network
            'file_server': '172.17.8.20', # DC Network
            'print_server': '172.17.8.21' # DC Network
        }
        
        # Generate workstation IPs for each subnet
        self.workstations = self._generate_workstations()
    
    def _generate_workstations(self) -> Dict[str, List[str]]:
        """Generate workstation IP addresses for each subnet"""
        workstations = {}
        
        # Router 1 workstations (excluding DC and DMZ which have servers)
        for subnet_name, subnet in self.router1_subnets.items():
            if subnet_name not in ['dc', 'dmz']:
                base = subnet.split('/')[0].rsplit('.', 1)[0]
                workstations[f'r1_{subnet_name}'] = [
                    f"{base}.{i}" for i in range(100, 110)
                ]
        
        # Router 2 workstations (excluding DMZ)
        for subnet_name, subnet in self.router2_subnets.items():
            if subnet_name != 'dmz':
                base = subnet.split('/')[0].rsplit('.', 1)[0]
                workstations[f'r2_{subnet_name}'] = [
                    f"{base}.{i}" for i in range(100, 110)
                ]
        
        return workstations
    
    def get_all_workstations(self) -> List[str]:
        """Get all workstation IPs as a flat list"""
        all_stations = []
        for stations in self.workstations.values():
            all_stations.extend(stations)
        return all_stations
    
    def get_random_workstation(self, exclude: Set[str] = None) -> str:
        """Get a random workstation IP"""
        exclude = exclude or set()
        available = [ip for ip in self.get_all_workstations() if ip not in exclude]
        return random.choice(available) if available else self.get_all_workstations()[0]


class TrafficPattern:
    """Defines realistic traffic patterns based on time of day"""
    
    @staticmethod
    def get_activity_multiplier() -> float:
        """Get traffic multiplier based on time of day"""
        hour = datetime.now().hour
        
        # Business hours: 8 AM - 5 PM (high activity)
        if 8 <= hour < 17:
            return 1.0
        # Early morning/evening: 6-8 AM, 5-7 PM (medium activity)
        elif (6 <= hour < 8) or (17 <= hour < 19):
            return 0.5
        # Night: 7 PM - 6 AM (low activity)
        else:
            return 0.1
    
    @staticmethod
    def should_generate_traffic(base_probability: float) -> bool:
        """Determine if traffic should be generated based on probability and time"""
        multiplier = TrafficPattern.get_activity_multiplier()
        adjusted_probability = base_probability * multiplier
        return random.random() < adjusted_probability


class TrafficGenerator:
    """Main traffic generator orchestrator"""
    
    def __init__(self, topology: NetworkTopology):
        self.topology = topology
        self.running = False
        self.tasks = []
        
        # Import traffic modules
        from email_traffic import EmailTrafficGenerator
        from ftp_traffic import FTPTrafficGenerator
        from dns_traffic import DNSTrafficGenerator
        from web_traffic import WebTrafficGenerator
        from file_traffic import FileShareTrafficGenerator
        
        # Initialize traffic generators
        self.email_gen = EmailTrafficGenerator(topology)
        self.ftp_gen = FTPTrafficGenerator(topology)
        self.dns_gen = DNSTrafficGenerator(topology)
        self.web_gen = WebTrafficGenerator(topology)
        self.file_gen = FileShareTrafficGenerator(topology)
        
        logger.info("Traffic Generator initialized")
    
    async def start(self):
        """Start all traffic generation tasks"""
        self.running = True
        logger.info("Starting traffic generation...")
        
        # Start DNS server (must run continuously)
        self.tasks.append(asyncio.create_task(self.dns_gen.run_server()))
        
        # Start traffic generation loops
        self.tasks.append(asyncio.create_task(self._email_loop()))
        self.tasks.append(asyncio.create_task(self._ftp_loop()))
        self.tasks.append(asyncio.create_task(self._web_loop()))
        self.tasks.append(asyncio.create_task(self._file_loop()))
        self.tasks.append(asyncio.create_task(self._dns_query_loop()))
        
        # Wait for all tasks
        await asyncio.gather(*self.tasks, return_exceptions=True)
    
    async def stop(self):
        """Stop all traffic generation"""
        logger.info("Stopping traffic generation...")
        self.running = False
        
        for task in self.tasks:
            task.cancel()
        
        await asyncio.gather(*self.tasks, return_exceptions=True)
        logger.info("Traffic generation stopped")
    
    async def _email_loop(self):
        """Generate email traffic periodically"""
        while self.running:
            try:
                if TrafficPattern.should_generate_traffic(0.3):  # 30% base probability
                    await self.email_gen.send_email()
                await asyncio.sleep(random.uniform(10, 30))  # 10-30 seconds between emails
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in email loop: {e}")
                await asyncio.sleep(5)
    
    async def _ftp_loop(self):
        """Generate FTP traffic periodically"""
        while self.running:
            try:
                if TrafficPattern.should_generate_traffic(0.2):  # 20% base probability
                    await self.ftp_gen.transfer_file()
                await asyncio.sleep(random.uniform(30, 90))  # 30-90 seconds between transfers
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in FTP loop: {e}")
                await asyncio.sleep(5)
    
    async def _web_loop(self):
        """Generate web traffic periodically"""
        while self.running:
            try:
                if TrafficPattern.should_generate_traffic(0.4):  # 40% base probability
                    await self.web_gen.browse_page()
                await asyncio.sleep(random.uniform(5, 20))  # 5-20 seconds between requests
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in web loop: {e}")
                await asyncio.sleep(5)
    
    async def _file_loop(self):
        """Generate file share traffic periodically"""
        while self.running:
            try:
                if TrafficPattern.should_generate_traffic(0.25):  # 25% base probability
                    await self.file_gen.access_file()
                await asyncio.sleep(random.uniform(20, 60))  # 20-60 seconds between accesses
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in file loop: {e}")
                await asyncio.sleep(5)
    
    async def _dns_query_loop(self):
        """Generate DNS queries periodically"""
        while self.running:
            try:
                if TrafficPattern.should_generate_traffic(0.5):  # 50% base probability
                    await self.dns_gen.query_domain()
                await asyncio.sleep(random.uniform(2, 10))  # 2-10 seconds between queries
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in DNS loop: {e}")
                await asyncio.sleep(5)


async def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Enterprise Network Traffic Generator')
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose logging')
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    topology = NetworkTopology()
    generator = TrafficGenerator(topology)
    
    # Setup signal handlers
    def signal_handler(sig, frame):
        logger.info("Received shutdown signal")
        asyncio.create_task(generator.stop())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        await generator.start()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt received")
    finally:
        await generator.stop()


if __name__ == "__main__":
    asyncio.run(main())
