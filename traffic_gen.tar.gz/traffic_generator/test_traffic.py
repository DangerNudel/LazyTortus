#!/usr/bin/env python3
"""
Traffic Generator Test Script
Verifies all components are working correctly
"""

import sys
import asyncio
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


async def test_imports():
    """Test that all modules can be imported"""
    logger.info("Testing module imports...")
    
    try:
        from traffic_generator import NetworkTopology, TrafficGenerator
        logger.info("✓ Main traffic_generator module imported")
        
        from email_traffic import EmailTrafficGenerator
        logger.info("✓ Email traffic module imported")
        
        from ftp_traffic import FTPTrafficGenerator
        logger.info("✓ FTP traffic module imported")
        
        from dns_traffic import DNSTrafficGenerator
        logger.info("✓ DNS traffic module imported")
        
        from web_traffic import WebTrafficGenerator
        logger.info("✓ Web traffic module imported")
        
        from file_traffic import FileShareTrafficGenerator
        logger.info("✓ File share traffic module imported")
        
        return True
    except ImportError as e:
        logger.error(f"✗ Import failed: {e}")
        return False


async def test_topology():
    """Test network topology initialization"""
    logger.info("\nTesting network topology...")
    
    try:
        from traffic_generator import NetworkTopology
        
        topology = NetworkTopology()
        
        # Verify servers
        assert topology.servers['email'] == '172.17.8.10'
        assert topology.servers['ftp'] == '172.17.8.11'
        assert topology.servers['dns'] == '172.17.8.53'
        logger.info("✓ Server IPs configured correctly")
        
        # Verify workstations
        workstations = topology.get_all_workstations()
        assert len(workstations) > 0
        logger.info(f"✓ Generated {len(workstations)} workstation IPs")
        
        # Verify subnets
        assert len(topology.router1_subnets) == 5
        assert len(topology.router2_subnets) == 5
        logger.info("✓ All subnets configured")
        
        return True
    except Exception as e:
        logger.error(f"✗ Topology test failed: {e}")
        return False


async def test_traffic_generators():
    """Test traffic generator initialization"""
    logger.info("\nTesting traffic generators...")
    
    try:
        from traffic_generator import NetworkTopology
        from email_traffic import EmailTrafficGenerator
        from ftp_traffic import FTPTrafficGenerator
        from dns_traffic import DNSTrafficGenerator
        from web_traffic import WebTrafficGenerator
        from file_traffic import FileShareTrafficGenerator
        
        topology = NetworkTopology()
        
        # Initialize each generator
        email_gen = EmailTrafficGenerator(topology)
        logger.info("✓ Email traffic generator initialized")
        
        ftp_gen = FTPTrafficGenerator(topology)
        logger.info("✓ FTP traffic generator initialized")
        
        dns_gen = DNSTrafficGenerator(topology)
        logger.info("✓ DNS traffic generator initialized")
        
        web_gen = WebTrafficGenerator(topology)
        logger.info("✓ Web traffic generator initialized")
        
        file_gen = FileShareTrafficGenerator(topology)
        logger.info("✓ File share traffic generator initialized")
        
        return True
    except Exception as e:
        logger.error(f"✗ Generator initialization failed: {e}")
        return False


async def test_dns_resolution():
    """Test DNS resolution"""
    logger.info("\nTesting DNS resolution...")
    
    try:
        from traffic_generator import NetworkTopology
        from dns_traffic import DNSTrafficGenerator
        
        topology = NetworkTopology()
        dns_gen = DNSTrafficGenerator(topology)
        
        # Test internal domain resolution
        internal_ip = dns_gen.resolve('mail.enterprise.local')
        assert internal_ip == topology.servers['email']
        logger.info(f"✓ Internal DNS: mail.enterprise.local -> {internal_ip}")
        
        # Test external domain resolution
        external_ip = dns_gen.resolve('www.google.com')
        assert external_ip.startswith('10.')
        logger.info(f"✓ External DNS: www.google.com -> {external_ip}")
        
        return True
    except Exception as e:
        logger.error(f"✗ DNS resolution test failed: {e}")
        return False


async def test_traffic_patterns():
    """Test traffic pattern calculations"""
    logger.info("\nTesting traffic patterns...")
    
    try:
        from traffic_generator import TrafficPattern
        
        # Test activity multiplier
        multiplier = TrafficPattern.get_activity_multiplier()
        assert 0 <= multiplier <= 1.0
        logger.info(f"✓ Activity multiplier: {multiplier * 100:.0f}%")
        
        # Test probability calculation
        should_generate = TrafficPattern.should_generate_traffic(0.5)
        logger.info(f"✓ Traffic probability calculated: {should_generate}")
        
        return True
    except Exception as e:
        logger.error(f"✗ Traffic pattern test failed: {e}")
        return False


async def test_single_traffic_generation():
    """Test generating a single piece of traffic for each type"""
    logger.info("\nTesting traffic generation (simulation mode)...")
    
    try:
        from traffic_generator import NetworkTopology
        from email_traffic import EmailTrafficGenerator
        from ftp_traffic import FTPTrafficGenerator
        from dns_traffic import DNSTrafficGenerator
        from web_traffic import WebTrafficGenerator
        from file_traffic import FileShareTrafficGenerator
        
        topology = NetworkTopology()
        
        # Test email generation
        logger.info("Testing email generation...")
        email_gen = EmailTrafficGenerator(topology)
        await email_gen.send_email()
        logger.info(f"✓ Email generated (total: {email_gen.emails_sent})")
        
        # Test FTP generation
        logger.info("Testing FTP generation...")
        ftp_gen = FTPTrafficGenerator(topology)
        await ftp_gen.transfer_file()
        logger.info(f"✓ FTP transfer generated (total: {ftp_gen.transfers_completed})")
        
        # Test DNS query
        logger.info("Testing DNS query...")
        dns_gen = DNSTrafficGenerator(topology)
        await dns_gen.query_domain()
        logger.info(f"✓ DNS query generated (total: {dns_gen.queries_sent})")
        
        # Test web browsing
        logger.info("Testing web browsing...")
        web_gen = WebTrafficGenerator(topology)
        await web_gen.browse_page()
        logger.info(f"✓ Web request generated (total: {web_gen.requests_made})")
        
        # Test file share access
        logger.info("Testing file share access...")
        file_gen = FileShareTrafficGenerator(topology)
        await file_gen.access_file()
        logger.info(f"✓ File share access generated (total: {file_gen.operations_performed})")
        
        return True
    except Exception as e:
        logger.error(f"✗ Traffic generation test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


async def run_all_tests():
    """Run all tests"""
    logger.info("=" * 70)
    logger.info("TRAFFIC GENERATOR TEST SUITE")
    logger.info("=" * 70)
    
    tests = [
        ("Module Imports", test_imports),
        ("Network Topology", test_topology),
        ("Traffic Generators", test_traffic_generators),
        ("DNS Resolution", test_dns_resolution),
        ("Traffic Patterns", test_traffic_patterns),
        ("Traffic Generation", test_single_traffic_generation),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            logger.error(f"Test '{test_name}' crashed: {e}")
            results.append((test_name, False))
    
    # Print summary
    logger.info("\n" + "=" * 70)
    logger.info("TEST SUMMARY")
    logger.info("=" * 70)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "PASSED ✓" if result else "FAILED ✗"
        logger.info(f"{test_name:.<50} {status}")
    
    logger.info("-" * 70)
    logger.info(f"Total: {passed}/{total} tests passed")
    logger.info("=" * 70)
    
    if passed == total:
        logger.info("\n✓ All tests passed! Traffic generator is ready to use.")
        logger.info("\nTo start the service:")
        logger.info("  sudo systemctl start traffic-generator")
        return 0
    else:
        logger.error(f"\n✗ {total - passed} test(s) failed. Please review errors above.")
        return 1


def main():
    """Main entry point"""
    try:
        exit_code = asyncio.run(run_all_tests())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        logger.info("\nTests interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Test suite crashed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
