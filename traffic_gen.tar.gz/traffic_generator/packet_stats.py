#!/usr/bin/env python3
"""
Real-time Packet Statistics
Displays live packet counts by protocol using tcpdump
Requires root privileges
"""

import subprocess
import re
import sys
import time
from collections import defaultdict
from datetime import datetime


def clear_screen():
    """Clear terminal screen"""
    print('\033[2J\033[H', end='')


def print_header():
    """Print statistics header"""
    print("=" * 80)
    print(" " * 25 + "REAL-TIME PACKET STATISTICS")
    print(" " * 20 + "Enterprise Network Traffic Generator")
    print("=" * 80)
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Capturing on: all interfaces")
    print("Press Ctrl+C to stop")
    print("=" * 80)
    print()


def parse_packet_line(line):
    """Parse tcpdump output line to extract protocol and IPs"""
    try:
        # Check for various protocols
        if 'SMTP' in line or '.25 >' in line or '> 172.17.8.10.25' in line:
            return 'SMTP'
        elif 'FTP' in line or '.21 >' in line or '> 172.17.8.11.21' in line:
            return 'FTP'
        elif 'domain' in line or '.53 >' in line or '> 172.17.8.53.53' in line:
            return 'DNS'
        elif '.80 >' in line or '.443 >' in line:
            return 'HTTP/HTTPS'
        elif '.445 >' in line:
            return 'SMB'
        elif 'SSH' in line or '.22 >' in line:
            return 'SSH'
        else:
            return 'Other'
    except Exception:
        return 'Other'


def run_packet_capture():
    """Run tcpdump and display statistics"""
    # Protocol counters
    protocol_counts = defaultdict(int)
    total_packets = 0
    start_time = time.time()
    last_update = time.time()
    
    # Relevant subnets and ports for our traffic generator
    capture_filter = (
        '(net 172.17.0.0/16 or net 172.18.0.0/16) and '
        '(port 25 or port 21 or port 53 or port 80 or port 443 or port 445)'
    )
    
    # Start tcpdump process
    try:
        cmd = ['tcpdump', '-i', 'any', '-n', '-l', capture_filter]
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            universal_newlines=True
        )
        
        clear_screen()
        print_header()
        
        for line in process.stdout:
            total_packets += 1
            protocol = parse_packet_line(line)
            protocol_counts[protocol] += 1
            
            # Update display every second
            current_time = time.time()
            if current_time - last_update >= 1.0:
                elapsed = current_time - start_time
                
                # Clear and redraw
                clear_screen()
                print_header()
                
                print("PROTOCOL STATISTICS:")
                print("-" * 80)
                print(f"{'Protocol':<20} {'Packets':<15} {'Percentage':<15} {'Rate (pkt/s)':<15}")
                print("-" * 80)
                
                # Sort by packet count
                sorted_protocols = sorted(
                    protocol_counts.items(),
                    key=lambda x: x[1],
                    reverse=True
                )
                
                for protocol, count in sorted_protocols:
                    percentage = (count / total_packets * 100) if total_packets > 0 else 0
                    rate = count / elapsed if elapsed > 0 else 0
                    print(f"{protocol:<20} {count:<15} {percentage:>6.2f}%        {rate:>6.2f}")
                
                print("-" * 80)
                print(f"{'TOTAL':<20} {total_packets:<15}")
                print()
                
                # Network summary
                print("NETWORK SUMMARY:")
                print("-" * 80)
                print(f"Total Packets:        {total_packets}")
                print(f"Elapsed Time:         {elapsed:.1f} seconds")
                print(f"Overall Rate:         {total_packets/elapsed:.2f} packets/second")
                print(f"Capture Filter:       {capture_filter[:60]}...")
                print()
                
                # Top source IPs (approximate from recent packets)
                print("MONITORING:")
                print("-" * 80)
                print("Email Server:         172.17.8.10  (Port 25)")
                print("FTP Server:           172.17.8.11  (Port 21)")
                print("DNS Server:           172.17.8.53  (Port 53)")
                print("Web Servers:          172.17.7.80, 172.18.7.80")
                print("File Server:          172.17.8.20  (Port 445)")
                print()
                
                last_update = current_time
        
    except PermissionError:
        print("\nError: This script requires root privileges to capture packets.")
        print("Please run with: sudo python3 packet_stats.py")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\nCapture stopped by user.")
        print("\nFinal Statistics:")
        print("-" * 80)
        
        elapsed = time.time() - start_time
        
        for protocol, count in sorted(protocol_counts.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total_packets * 100) if total_packets > 0 else 0
            print(f"{protocol:<20} {count:>10} packets ({percentage:>6.2f}%)")
        
        print("-" * 80)
        print(f"Total:               {total_packets:>10} packets")
        print(f"Duration:            {elapsed:>10.1f} seconds")
        print(f"Average Rate:        {total_packets/elapsed:>10.2f} pkt/s")
        print()
        
        sys.exit(0)
    except FileNotFoundError:
        print("\nError: tcpdump not found. Please install it:")
        print("  sudo apt install tcpdump")
        sys.exit(1)
    except Exception as e:
        print(f"\nError: {e}")
        sys.exit(1)


def main():
    """Main entry point"""
    print("Starting packet capture...")
    print("This will capture traffic from the traffic generator.")
    print()
    
    run_packet_capture()


if __name__ == "__main__":
    main()
