# Wireshark Filter Guide for Traffic Generator
# Save useful filters for quick access

## CAPTURE FILTERS (use when starting capture)
## These are BPF (Berkeley Packet Filter) syntax

# Capture all traffic from the lab subnets
host 172.17.0.0/16 or host 172.18.0.0/16

# Capture only specific protocols
port 25 or port 21 or port 53 or port 80 or port 443 or port 445

# Capture traffic to/from servers
host 172.17.8.10 or host 172.17.8.11 or host 172.17.8.53 or host 172.17.8.20

# Capture all traffic except SSH (to reduce noise)
not port 22

# Capture specific subnet
net 172.17.4.0/24

## DISPLAY FILTERS (use after capture is loaded)
## These are Wireshark's display filter syntax

### Traffic by Protocol

# Email (SMTP) traffic
smtp

# FTP traffic
ftp or ftp-data

# DNS queries and responses
dns

# HTTP traffic
http

# HTTPS/SSL traffic
tls or ssl

# SMB/CIFS file sharing
smb or smb2

# All application protocols generated
smtp or ftp or dns or http or tls or smb2

### Traffic by IP Address

# All traffic from Router 1 subnets
ip.src == 172.17.0.0/16 or ip.dst == 172.17.0.0/16

# All traffic from Router 2 subnets
ip.src == 172.18.0.0/16 or ip.dst == 172.18.0.0/16

# Traffic to/from email server
ip.addr == 172.17.8.10

# Traffic to/from DNS server
ip.addr == 172.17.8.53

# Traffic from Air Network workstations
ip.src == 172.17.4.0/24

# Traffic from Finance Network workstations
ip.src == 172.18.4.0/24

### Traffic by Port

# SMTP (port 25)
tcp.port == 25

# FTP (port 21)
tcp.port == 21

# DNS (port 53)
udp.port == 53

# HTTP (port 80)
tcp.port == 80

# HTTPS (port 443)
tcp.port == 443

# SMB (port 445)
tcp.port == 445

### Combined Filters

# All email traffic (SMTP conversations)
tcp.port == 25 and (ip.src == 172.17.0.0/16 or ip.src == 172.18.0.0/16)

# DNS queries from workstations to DNS server
dns and ip.dst == 172.17.8.53

# Web traffic from all subnets
(tcp.port == 80 or tcp.port == 443) and (ip.src == 172.17.0.0/16 or ip.src == 172.18.0.0/16)

# FTP file transfers with data
ftp-data and ip.addr == 172.17.8.11

# File share traffic from Finance network
tcp.port == 445 and ip.src == 172.18.4.0/24

### Traffic Analysis Filters

# Email with attachments (larger packets)
smtp and tcp.len > 1000

# Large file transfers
tcp.len > 1460 and (tcp.port == 21 or tcp.port == 445)

# DNS response time analysis
dns.time > 0.1

# HTTP errors
http.response.code >= 400

# Failed connection attempts
tcp.flags.syn == 1 and tcp.flags.ack == 0

### Department-Specific Traffic

# Air Force network traffic
ip.addr == 172.17.4.0/24

# Ground network traffic
ip.addr == 172.17.3.0/24

# Naval network traffic
ip.addr == 172.17.2.0/24

# Finance network traffic
ip.addr == 172.18.4.0/24

# Leadership network traffic
ip.addr == 172.18.8.0/24

# Transportation network traffic
ip.addr == 172.18.3.0/24

### Time-Based Analysis

# Traffic during business hours (example: 9 AM to 5 PM)
# Note: Use Statistics -> IO Graph for time-based visualization

# Conversations between specific IPs
ip.addr == 172.17.4.105 and ip.addr == 172.17.8.10

### Statistics Menu Useful Options

# Protocol Hierarchy: Statistics -> Protocol Hierarchy
#   Shows breakdown of all protocols in capture

# Conversations: Statistics -> Conversations
#   Shows all IP conversations and data transferred

# I/O Graph: Statistics -> I/O Graph
#   Visualize traffic over time

# HTTP Analysis: Statistics -> HTTP -> Requests
#   See all HTTP requests

# DNS Analysis: Statistics -> DNS
#   Analyze DNS queries and responses

### Export Options

# Export HTTP objects: File -> Export Objects -> HTTP
# Export SMTP messages: File -> Export Objects -> IMF
# Export FTP data: File -> Export Objects -> FTP-DATA

### Tips for Analysis

1. Start with broad filters (e.g., "ip.src == 172.17.0.0/16")
2. Narrow down to specific protocols
3. Use Follow Stream (right-click packet -> Follow -> TCP Stream)
4. Check Statistics for overview before diving into packets
5. Use coloring rules to highlight different protocols
6. Create custom columns for specific fields

### Example Analysis Workflow

1. Capture for 5 minutes with: "net 172.17.0.0/16 or net 172.18.0.0/16"
2. Apply display filter: "smtp or ftp or dns or http or smb2"
3. Check Protocol Hierarchy to see distribution
4. Filter by specific protocol to analyze
5. Follow TCP streams for detailed conversations
6. Export interesting objects/data

### Custom Color Rules (View -> Coloring Rules)

# SMTP traffic - Light Blue
smtp

# FTP traffic - Light Green  
ftp or ftp-data

# DNS traffic - Light Yellow
dns

# HTTP/HTTPS - Light Purple
http or tls

# SMB traffic - Light Pink
smb or smb2

# Errors - Red
tcp.analysis.flags or http.response.code >= 400

### Saving Filters

Save frequently used filters:
1. Enter filter in display filter box
2. Click bookmark icon
3. Give it a name
4. Access from dropdown or filter toolbar

### Performance Tips

- Use capture filters to reduce captured data
- Close unnecessary columns
- Disable unused protocol dissectors
- Save filtered packets to new file for focused analysis

---

For more information:
- Wireshark User Guide: https://www.wireshark.org/docs/wsug_html_chunked/
- Display Filter Reference: https://www.wireshark.org/docs/dfref/
