#!/usr/bin/env python3
"""
Email Traffic Generator
Simulates SMTP email traffic in the enterprise network
"""

import asyncio
import logging
import random
import socket
from datetime import datetime
from typing import List, Tuple

logger = logging.getLogger(__name__)


class EmailTrafficGenerator:
    """Generate realistic email traffic"""
    
    # Email subjects for different departments
    EMAIL_SUBJECTS = {
        'general': [
            'Weekly Status Report',
            'Meeting Minutes - Team Sync',
            'Q4 Planning Discussion',
            'Project Update',
            'Action Items Follow-up',
            'FYI: Policy Update',
            'Quarterly Review',
            'Monthly Newsletter'
        ],
        'finance': [
            'Budget Approval Request',
            'Expense Report Submission',
            'Financial Statement Review',
            'Invoice Processing',
            'Cost Analysis Report'
        ],
        'leadership': [
            'Strategic Planning Session',
            'Board Meeting Agenda',
            'Executive Summary',
            'Organizational Update',
            'Leadership Team Sync'
        ],
        'operations': [
            'Maintenance Schedule',
            'Incident Report',
            'System Status Update',
            'Resource Allocation',
            'Operational Metrics'
        ]
    }
    
    DOCUMENT_TYPES = [
        'report.pdf', 'analysis.xlsx', 'presentation.pptx',
        'memo.docx', 'budget.xlsx', 'schedule.pdf',
        'diagram.png', 'data.csv', 'summary.docx'
    ]
    
    def __init__(self, topology):
        self.topology = topology
        self.email_server = topology.servers['email']
        self.smtp_port = 25
        
        # Email statistics
        self.emails_sent = 0
        self.emails_with_attachments = 0
    
    def _generate_email_content(self) -> Tuple[str, str, str, bool, int]:
        """
        Generate realistic email content
        Returns: (from_ip, to_ip, subject, has_attachment, attachment_size)
        """
        # Select sender and recipient(s)
        all_stations = self.topology.get_all_workstations()
        from_ip = random.choice(all_stations)
        to_ip = random.choice([ip for ip in all_stations if ip != from_ip])
        
        # Select subject based on sender's subnet
        if 'finance' in str(from_ip):
            category = 'finance'
        elif 'leadership' in str(from_ip):
            category = 'leadership'
        elif any(x in str(from_ip) for x in ['air', 'ground', 'naval', 'transportation']):
            category = 'operations'
        else:
            category = 'general'
        
        subject = random.choice(self.EMAIL_SUBJECTS.get(category, self.EMAIL_SUBJECTS['general']))
        
        # Determine if email has attachment (30% probability)
        has_attachment = random.random() < 0.3
        attachment_size = 0
        
        if has_attachment:
            # Attachment size between 100KB and 5MB
            attachment_size = random.randint(100 * 1024, 5 * 1024 * 1024)
        
        return from_ip, to_ip, subject, has_attachment, attachment_size
    
    def _create_smtp_session(self, from_ip: str, to_ip: str, subject: str,
                            has_attachment: bool, attachment_size: int) -> List[bytes]:
        """Create SMTP session packets"""
        packets = []
        
        # Simulate SMTP conversation
        # Client connects
        packets.append(b"220 mail.enterprise.local ESMTP\r\n")
        
        # EHLO
        packets.append(f"EHLO workstation-{from_ip.replace('.', '-')}\r\n".encode())
        packets.append(b"250-mail.enterprise.local\r\n250-SIZE 52428800\r\n250 HELP\r\n")
        
        # MAIL FROM
        from_email = f"user{from_ip.split('.')[-1]}@enterprise.local"
        packets.append(f"MAIL FROM:<{from_email}>\r\n".encode())
        packets.append(b"250 OK\r\n")
        
        # RCPT TO
        to_email = f"user{to_ip.split('.')[-1]}@enterprise.local"
        packets.append(f"RCPT TO:<{to_email}>\r\n".encode())
        packets.append(b"250 OK\r\n")
        
        # DATA
        packets.append(b"DATA\r\n")
        packets.append(b"354 Start mail input; end with <CRLF>.<CRLF>\r\n")
        
        # Email headers
        email_data = f"From: {from_email}\r\n"
        email_data += f"To: {to_email}\r\n"
        email_data += f"Subject: {subject}\r\n"
        email_data += f"Date: {datetime.now().strftime('%a, %d %b %Y %H:%M:%S -0500')}\r\n"
        email_data += "MIME-Version: 1.0\r\n"
        
        if has_attachment:
            email_data += "Content-Type: multipart/mixed; boundary=\"boundary123\"\r\n\r\n"
            email_data += "--boundary123\r\n"
            email_data += "Content-Type: text/plain\r\n\r\n"
            email_data += "Please find the attached document.\r\n\r\n"
            email_data += "--boundary123\r\n"
            
            doc_name = random.choice(self.DOCUMENT_TYPES)
            email_data += f"Content-Type: application/octet-stream; name=\"{doc_name}\"\r\n"
            email_data += "Content-Transfer-Encoding: base64\r\n"
            email_data += f"Content-Disposition: attachment; filename=\"{doc_name}\"\r\n\r\n"
            
            # Simulate base64 attachment data (shortened for performance)
            lines = attachment_size // 76  # 76 chars per line in base64
            for _ in range(min(lines, 100)):  # Limit to 100 lines for simulation
                email_data += "QmFzZTY0RW5jb2RlZERhdGFTaW11bGF0aW9uRm9yVHJhZmZpY0dlbmVyYXRvcg==\r\n"
            
            email_data += "--boundary123--\r\n"
        else:
            email_data += "Content-Type: text/plain\r\n\r\n"
            email_data += f"This is a message regarding: {subject}\r\n\r\n"
            email_data += "Please review and provide your feedback.\r\n\r\n"
            email_data += "Best regards\r\n"
        
        email_data += ".\r\n"
        packets.append(email_data.encode())
        packets.append(b"250 OK: message queued\r\n")
        
        # QUIT
        packets.append(b"QUIT\r\n")
        packets.append(b"221 Bye\r\n")
        
        return packets
    
    async def send_email(self):
        """Simulate sending an email"""
        try:
            from_ip, to_ip, subject, has_attachment, attachment_size = self._generate_email_content()
            
            # Create socket to simulate traffic
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            try:
                # Try to bind to source IP (may fail if not available)
                sock.bind((from_ip, 0))
            except OSError:
                logger.debug(f"Could not bind to {from_ip}, using default interface")
            
            try:
                # Attempt connection to mail server
                sock.settimeout(2)
                await asyncio.get_event_loop().sock_connect(sock, (self.email_server, self.smtp_port))
                
                # Send SMTP packets
                packets = self._create_smtp_session(from_ip, to_ip, subject, 
                                                   has_attachment, attachment_size)
                
                for packet in packets:
                    await asyncio.get_event_loop().sock_sendall(sock, packet)
                    await asyncio.sleep(0.01)  # Small delay between packets
                
                self.emails_sent += 1
                if has_attachment:
                    self.emails_with_attachments += 1
                
                attachment_info = f" with {attachment_size/1024:.1f}KB attachment" if has_attachment else ""
                logger.info(f"Email sent: {from_ip} -> {to_ip} | Subject: '{subject}'{attachment_info}")
                
            except (ConnectionRefusedError, OSError, asyncio.TimeoutError) as e:
                # Server not running - just log the simulated traffic
                logger.debug(f"Simulated email: {from_ip} -> {self.email_server} -> {to_ip}")
                logger.debug(f"  Subject: '{subject}', Attachment: {has_attachment}")
                self.emails_sent += 1
                if has_attachment:
                    self.emails_with_attachments += 1
            
            finally:
                sock.close()
                
        except Exception as e:
            logger.error(f"Error generating email traffic: {e}")
    
    async def run_server(self):
        """Run a simple SMTP server (optional)"""
        try:
            server = await asyncio.start_server(
                self._handle_smtp_connection,
                self.email_server,
                self.smtp_port
            )
            
            logger.info(f"SMTP server listening on {self.email_server}:{self.smtp_port}")
            
            async with server:
                await server.serve_forever()
                
        except PermissionError:
            logger.warning("Cannot bind to port 25 (requires root). SMTP server will not start.")
        except Exception as e:
            logger.error(f"SMTP server error: {e}")
    
    async def _handle_smtp_connection(self, reader, writer):
        """Handle incoming SMTP connection"""
        addr = writer.get_extra_info('peername')
        logger.debug(f"SMTP connection from {addr[0]}")
        
        try:
            # Send greeting
            writer.write(b"220 mail.enterprise.local ESMTP\r\n")
            await writer.drain()
            
            while True:
                data = await reader.read(1024)
                if not data:
                    break
                
                message = data.decode().strip().upper()
                
                if message.startswith('EHLO') or message.startswith('HELO'):
                    writer.write(b"250-mail.enterprise.local\r\n250 HELP\r\n")
                elif message.startswith('MAIL FROM'):
                    writer.write(b"250 OK\r\n")
                elif message.startswith('RCPT TO'):
                    writer.write(b"250 OK\r\n")
                elif message.startswith('DATA'):
                    writer.write(b"354 Start mail input\r\n")
                elif message == 'QUIT':
                    writer.write(b"221 Bye\r\n")
                    await writer.drain()
                    break
                else:
                    writer.write(b"250 OK\r\n")
                
                await writer.drain()
        
        except Exception as e:
            logger.error(f"Error handling SMTP connection: {e}")
        finally:
            writer.close()
            await writer.wait_closed()
