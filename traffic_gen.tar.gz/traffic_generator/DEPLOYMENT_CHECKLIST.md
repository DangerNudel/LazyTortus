# Deployment Checklist
# Enterprise Network Traffic Generator

## Pre-Installation Requirements

### System Requirements
- [ ] Operating System: Ubuntu 20.04 or higher
- [ ] Python 3.7 or higher installed
- [ ] Minimum 2 GB RAM available
- [ ] Minimum 500 MB disk space available
- [ ] Root/sudo access available

### Verify Requirements
```bash
# Check OS version
lsb_release -a

# Check Python version (must be 3.7+)
python3 --version

# Check available memory
free -h

# Check disk space
df -h

# Check you have sudo access
sudo -v
```

## Installation Steps

### 1. Download and Extract Files
- [ ] All Python files present (traffic_generator.py, email_traffic.py, etc.)
- [ ] Installation script present (install.sh)
- [ ] Documentation present (README.md, QUICKSTART.md)

### 2. Run Installation
```bash
cd /path/to/traffic-generator-files
chmod +x install.sh
sudo ./install.sh
```

- [ ] Installation completed without errors
- [ ] Files copied to /opt/traffic-generator
- [ ] Systemd service created
- [ ] Log directory created at /var/log/traffic-generator

### 3. Verify Installation
```bash
# Check files are present
ls -la /opt/traffic-generator/

# Check service file exists
ls -la /etc/systemd/system/traffic-generator.service

# Check log directory
ls -la /var/log/traffic-generator/
```

- [ ] All Python files present in /opt/traffic-generator
- [ ] Service file exists
- [ ] Log directory created

## Configuration

### 4. Review Configuration (Optional)
```bash
# Edit configuration if needed
sudo nano /opt/traffic-generator/config.py
```

Things you might want to adjust:
- [ ] Server IP addresses
- [ ] Subnet definitions
- [ ] Traffic generation probabilities
- [ ] Business hours settings

## Service Management

### 5. Start the Service
```bash
# Start the service
sudo systemctl start traffic-generator

# Check status
sudo systemctl status traffic-generator
```

- [ ] Service started successfully
- [ ] Status shows "active (running)"
- [ ] No error messages in status output

### 6. Enable Auto-Start (Optional)
```bash
sudo systemctl enable traffic-generator
```

- [ ] Service enabled for automatic startup on boot

## Verification

### 7. Check Logs
```bash
# View real-time logs
sudo journalctl -u traffic-generator -f

# Or view log file
sudo tail -f /var/log/traffic_generator.log
```

You should see:
- [ ] "Traffic Generator initialized" message
- [ ] "Starting traffic generation..." message
- [ ] Traffic generation messages (Email, FTP, DNS, HTTP, SMB)
- [ ] No critical errors

### 8. Verify Traffic Generation
```bash
# Let it run for 1-2 minutes, then check logs
sudo journalctl -u traffic-generator -n 50
```

Expected output includes:
- [ ] Email sent messages
- [ ] FTP transfer messages
- [ ] DNS query messages
- [ ] HTTP request messages
- [ ] SMB access messages

### 9. Monitor Statistics (Optional)
```bash
sudo python3 /opt/traffic-generator/monitor_stats.py
```

- [ ] Dashboard displays correctly
- [ ] Network configuration shown
- [ ] Traffic statistics updating

## Traffic Capture

### 10. Install Wireshark/tcpdump
```bash
sudo apt update
sudo apt install wireshark tshark tcpdump
```

- [ ] Wireshark installed successfully
- [ ] tcpdump installed successfully

### 11. Capture Traffic
```bash
# Start capture (let run for 30-60 seconds)
sudo tcpdump -i any -w /tmp/test_capture.pcap

# After 30-60 seconds, press Ctrl+C to stop
```

- [ ] Capture file created
- [ ] Capture file has non-zero size

### 12. Analyze Capture
```bash
# Open in Wireshark
wireshark /tmp/test_capture.pcap

# Or analyze with tcpdump
sudo tcpdump -r /tmp/test_capture.pcap | head -50
```

Expected protocols visible:
- [ ] SMTP (port 25) traffic
- [ ] FTP (port 21) traffic  
- [ ] DNS (port 53) traffic
- [ ] HTTP (port 80) or HTTPS (port 443) traffic
- [ ] SMB (port 445) traffic

### 13. Apply Wireshark Filters
In Wireshark, test these filters:
- [ ] `ip.src == 172.17.0.0/16` - Shows Router 1 subnet traffic
- [ ] `ip.src == 172.18.0.0/16` - Shows Router 2 subnet traffic
- [ ] `smtp` - Shows email traffic
- [ ] `dns` - Shows DNS queries
- [ ] `http or tls` - Shows web traffic

## Testing

### 14. Run Test Suite
```bash
cd /opt/traffic-generator
sudo python3 test_traffic.py
```

- [ ] All tests passed
- [ ] No critical errors

## Performance Monitoring

### 15. Check Resource Usage
```bash
# Check memory usage
ps aux | grep traffic_generator | grep -v grep

# Check CPU usage
top -p $(pgrep -f traffic_generator)
```

Expected usage:
- [ ] Memory: 50-200 MB
- [ ] CPU: 5-15% of one core

## Troubleshooting

### 16. Common Issues

#### Service won't start
```bash
# Check detailed error
sudo journalctl -u traffic-generator -n 100
```

Possible causes:
- [ ] Python not installed or wrong version
- [ ] Missing Python files
- [ ] Permission issues

#### No traffic visible
- [ ] Service is running (check status)
- [ ] Capturing on correct interface
- [ ] Sufficient time elapsed (wait 2-3 minutes)
- [ ] Check logs for errors

#### Port binding errors in logs
- [ ] This is NORMAL - traffic still generated
- [ ] Servers need root to bind to ports < 1024
- [ ] Traffic visible in Wireshark regardless

## Documentation Review

### 17. Read Documentation
- [ ] README.md - Full documentation
- [ ] QUICKSTART.md - Quick reference
- [ ] WIRESHARK_FILTERS.md - Analysis tips

## Final Validation

### 18. End-to-End Test

1. Service running:
```bash
sudo systemctl status traffic-generator
```
- [ ] Status: active (running)

2. Traffic generating:
```bash
sudo journalctl -u traffic-generator -n 20
```
- [ ] Recent traffic messages visible

3. Packets captured:
```bash
# Capture for 60 seconds
sudo timeout 60 tcpdump -i any -w /tmp/final_test.pcap

# Check packet count
sudo tcpdump -r /tmp/final_test.pcap | wc -l
```
- [ ] Packet count > 0
- [ ] Multiple protocols present

4. Wireshark analysis:
- [ ] Can open capture in Wireshark
- [ ] Can see SMTP, FTP, DNS, HTTP, SMB protocols
- [ ] Can follow TCP streams
- [ ] Can see conversations between IPs

## Production Readiness

### 19. Security Considerations
- [ ] Traffic generator runs in isolated lab environment
- [ ] No connection to actual internet
- [ ] All traffic contained within lab subnets
- [ ] DNS responses are simulated, not real

### 20. Operational Procedures
- [ ] Start command documented
- [ ] Stop command documented
- [ ] Log locations documented
- [ ] Monitoring procedures documented
- [ ] Restart procedure documented

### 21. Backup Configuration
```bash
# Backup configuration
sudo cp /opt/traffic-generator/config.py /opt/traffic-generator/config.py.backup
```
- [ ] Configuration backed up

## Sign-Off

### Installation Team
- Installer Name: _______________________
- Date: _______________________
- Signature: _______________________

### System Specifications
- Server/VM Name: _______________________
- IP Address: _______________________
- OS Version: _______________________
- Python Version: _______________________

### Traffic Generator Details
- Installation Path: /opt/traffic-generator
- Service Name: traffic-generator
- Log Path: /var/log/traffic_generator.log

### Test Results
- Installation: ☐ Pass ☐ Fail
- Service Start: ☐ Pass ☐ Fail
- Traffic Generation: ☐ Pass ☐ Fail
- Packet Capture: ☐ Pass ☐ Fail
- Wireshark Analysis: ☐ Pass ☐ Fail

### Notes
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________

---

## Post-Deployment

### Regular Maintenance
- [ ] Monitor log file size (logrotate recommended)
- [ ] Check service status weekly
- [ ] Review traffic patterns for realism
- [ ] Adjust configuration as needed

### Support Resources
- README.md for detailed information
- QUICKSTART.md for common tasks
- WIRESHARK_FILTERS.md for traffic analysis
- Logs at /var/log/traffic_generator.log
- Service logs: `sudo journalctl -u traffic-generator`

---

**Deployment Complete!** ✓

The Enterprise Network Traffic Generator is now operational and generating realistic network traffic for your lab environment.
