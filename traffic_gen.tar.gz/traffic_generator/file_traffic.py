#!/usr/bin/env python3
"""
File Share Traffic Generator
Simulates SMB/CIFS file sharing traffic in the enterprise network
"""

import asyncio
import logging
import random
import socket
from typing import Tuple

logger = logging.getLogger(__name__)


class FileShareTrafficGenerator:
    """Generate realistic file share traffic"""
    
    # Common file operations
    OPERATIONS = ['read', 'write', 'list', 'create', 'delete']
    
    # Common shared folders
    SHARES = [
        'Department',
        'Projects',
        'Documents',
        'Finance',
        'HR',
        'Operations',
        'Shared',
        'Public'
    ]
    
    # File types commonly accessed on shares
    FILE_TYPES = {
        'office': [
            'Q4-Report.docx', 'Budget-2024.xlsx', 'Presentation.pptx',
            'Meeting-Notes.docx', 'Financial-Analysis.xlsx', 'Project-Plan.docx'
        ],
        'data': [
            'customer-data.csv', 'sales-report.xlsx', 'inventory.csv',
            'analytics.xlsx', 'metrics.csv', 'export.xlsx'
        ],
        'pdfs': [
            'Policy-Manual.pdf', 'Technical-Spec.pdf', 'Compliance-Report.pdf',
            'Contract.pdf', 'Invoice.pdf', 'Proposal.pdf'
        ],
        'images': [
            'diagram.png', 'logo.png', 'screenshot.jpg',
            'chart.png', 'photo.jpg', 'graphic.svg'
        ]
    }
    
    def __init__(self, topology):
        self.topology = topology
        self.file_server = topology.servers['file_server']
        self.smb_port = 445  # SMB over TCP
        
        # Operation statistics
        self.operations_performed = 0
        self.bytes_accessed = 0
    
    def _generate_operation_params(self) -> Tuple[str, str, str, str, int]:
        """
        Generate file operation parameters
        Returns: (client_ip, operation, share, filename, file_size)
        """
        client_ip = self.topology.get_random_workstation()
        operation = random.choice(self.OPERATIONS)
        share = random.choice(self.SHARES)
        
        # Select file type and name
        file_category = random.choice(list(self.FILE_TYPES.keys()))
        filename = random.choice(self.FILE_TYPES[file_category])
        
        # Generate file size based on type
        if file_category == 'office':
            file_size = random.randint(50 * 1024, 5 * 1024 * 1024)  # 50KB - 5MB
        elif file_category == 'data':
            file_size = random.randint(100 * 1024, 50 * 1024 * 1024)  # 100KB - 50MB
        elif file_category == 'pdfs':
            file_size = random.randint(200 * 1024, 20 * 1024 * 1024)  # 200KB - 20MB
        else:  # images
            file_size = random.randint(500 * 1024, 10 * 1024 * 1024)  # 500KB - 10MB
        
        return client_ip, operation, share, filename, file_size
    
    def _create_smb_negotiate(self) -> bytes:
        """Create SMB Negotiate Protocol Request"""
        # Simplified SMB2 negotiate request
        smb_header = b'\xfeSMB'  # SMB2 signature
        smb_header += b'\x00' * 60  # Simplified header
        
        # Negotiate request
        negotiate = b'\x00\x00'  # Structure size
        negotiate += b'\x02\x00'  # Dialect count
        negotiate += b'\x00' * 32  # Security mode and capabilities
        
        return smb_header + negotiate
    
    def _create_smb_session_setup(self) -> bytes:
        """Create SMB Session Setup Request"""
        smb_header = b'\xfeSMB'
        smb_header += b'\x01' * 60  # Simplified header with session setup command
        
        session_setup = b'\x00' * 20  # Simplified session setup
        
        return smb_header + session_setup
    
    def _create_smb_tree_connect(self, share: str) -> bytes:
        """Create SMB Tree Connect Request"""
        smb_header = b'\xfeSMB'
        smb_header += b'\x03' * 60  # Simplified header with tree connect command
        
        path = f"\\\\{self.file_server}\\{share}".encode('utf-16le')
        tree_connect = b'\x00\x09'  # Structure size
        tree_connect += b'\x00' * 6  # Flags
        tree_connect += path
        
        return smb_header + tree_connect
    
    def _create_smb_create_request(self, filename: str) -> bytes:
        """Create SMB Create/Open File Request"""
        smb_header = b'\xfeSMB'
        smb_header += b'\x05' * 60  # Simplified header with create command
        
        filename_bytes = filename.encode('utf-16le')
        create = b'\x00\x39'  # Structure size
        create += b'\x00' * 50  # Access mask, file attributes, etc.
        create += filename_bytes
        
        return smb_header + create
    
    def _create_smb_read_request(self, file_size: int) -> bytes:
        """Create SMB Read Request"""
        smb_header = b'\xfeSMB'
        smb_header += b'\x08' * 60  # Simplified header with read command
        
        read = b'\x00\x31'  # Structure size
        read += b'\x00' * 10  # Padding
        read += struct.pack('<I', file_size)  # Length to read
        read += b'\x00' * 20  # Offset and other fields
        
        return smb_header + read
    
    def _create_smb_write_request(self, file_size: int) -> bytes:
        """Create SMB Write Request"""
        smb_header = b'\xfeSMB'
        smb_header += b'\x09' * 60  # Simplified header with write command
        
        write = b'\x00\x31'  # Structure size
        write += b'\x00' * 10  # Padding
        write += struct.pack('<I', file_size)  # Length to write
        write += b'\x00' * 20  # Offset and other fields
        
        return smb_header + write
    
    async def access_file(self):
        """Simulate file share access"""
        try:
            client_ip, operation, share, filename, file_size = self._generate_operation_params()
            
            # Create socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            try:
                # Try to bind to client IP
                sock.bind((client_ip, 0))
            except OSError:
                logger.debug(f"Could not bind to {client_ip}, using default interface")
            
            try:
                # Attempt connection to file server
                sock.settimeout(2)
                await asyncio.get_event_loop().sock_connect(sock, (self.file_server, self.smb_port))
                
                # SMB negotiation sequence
                negotiate = self._create_smb_negotiate()
                await asyncio.get_event_loop().sock_sendall(sock, negotiate)
                await asyncio.sleep(0.01)
                
                session_setup = self._create_smb_session_setup()
                await asyncio.get_event_loop().sock_sendall(sock, session_setup)
                await asyncio.sleep(0.01)
                
                tree_connect = self._create_smb_tree_connect(share)
                await asyncio.get_event_loop().sock_sendall(sock, tree_connect)
                await asyncio.sleep(0.01)
                
                # Perform file operation
                if operation in ['read', 'write']:
                    create_req = self._create_smb_create_request(filename)
                    await asyncio.get_event_loop().sock_sendall(sock, create_req)
                    await asyncio.sleep(0.01)
                    
                    if operation == 'read':
                        read_req = self._create_smb_read_request(file_size)
                        await asyncio.get_event_loop().sock_sendall(sock, read_req)
                        
                        # Simulate reading data in chunks
                        chunks = file_size // 65536  # 64KB chunks
                        for _ in range(min(chunks, 10)):
                            await asyncio.sleep(0.001)
                        
                        self.bytes_accessed += file_size
                    
                    elif operation == 'write':
                        write_req = self._create_smb_write_request(file_size)
                        await asyncio.get_event_loop().sock_sendall(sock, write_req)
                        
                        # Simulate writing data in chunks
                        chunks = file_size // 65536  # 64KB chunks
                        for _ in range(min(chunks, 10)):
                            await asyncio.sleep(0.001)
                        
                        self.bytes_accessed += file_size
                
                self.operations_performed += 1
                
                size_kb = file_size / 1024
                logger.info(f"SMB {operation.upper()}: {client_ip} -> {self.file_server} | "
                          f"Share: \\\\{self.file_server}\\{share}\\{filename} ({size_kb:.1f}KB)")
                
            except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
                # Server not running - just log the simulated traffic
                logger.debug(f"Simulated SMB {operation}: {client_ip} -> {self.file_server}")
                logger.debug(f"  Share: \\\\{self.file_server}\\{share}\\{filename}")
                logger.debug(f"  Size: {file_size/1024:.1f}KB")
                
                self.operations_performed += 1
                if operation in ['read', 'write']:
                    self.bytes_accessed += file_size
            
            finally:
                sock.close()
                
        except Exception as e:
            logger.error(f"Error generating file share traffic: {e}")
    
    async def run_server(self):
        """Run a simple SMB server (optional)"""
        try:
            server = await asyncio.start_server(
                self._handle_smb_connection,
                self.file_server,
                self.smb_port
            )
            
            logger.info(f"SMB server listening on {self.file_server}:{self.smb_port}")
            
            async with server:
                await server.serve_forever()
                
        except PermissionError:
            logger.warning("Cannot bind to port 445 (requires root). SMB server will not start.")
        except Exception as e:
            logger.error(f"SMB server error: {e}")
    
    async def _handle_smb_connection(self, reader, writer):
        """Handle incoming SMB connection"""
        addr = writer.get_extra_info('peername')
        logger.debug(f"SMB connection from {addr[0]}")
        
        try:
            while True:
                data = await reader.read(4096)
                if not data:
                    break
                
                # Simple echo response for simulation
                writer.write(b'\xfeSMB' + b'\x00' * 60)
                await writer.drain()
        
        except Exception as e:
            logger.error(f"Error handling SMB connection: {e}")
        finally:
            writer.close()
            await writer.wait_closed()


# Import struct for packing
import struct
