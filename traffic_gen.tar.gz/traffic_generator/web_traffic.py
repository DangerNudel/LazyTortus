#!/usr/bin/env python3
"""
Web Traffic Generator
Simulates HTTP/HTTPS web browsing traffic in the enterprise network
"""

import asyncio
import logging
import random
import socket
from typing import List, Tuple

logger = logging.getLogger(__name__)


class WebTrafficGenerator:
    """Generate realistic web browsing traffic"""
    
    # Common URLs for internal and simulated external browsing
    INTERNAL_URLS = [
        '/portal/dashboard',
        '/portal/employee',
        '/portal/reports',
        '/portal/documents',
        '/intranet/home',
        '/intranet/news',
        '/intranet/hr',
        '/intranet/policies',
        '/wiki/main',
        '/wiki/projects',
        '/files/shared',
        '/files/department'
    ]
    
    EXTERNAL_URLS = [
        '/search?q=enterprise+solutions',
        '/news/technology',
        '/docs/api/reference',
        '/support/kb/article',
        '/downloads/software',
        '/products/overview',
        '/blog/latest-updates',
        '/about/company'
    ]
    
    USER_AGENTS = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0'
    ]
    
    def __init__(self, topology):
        self.topology = topology
        self.web_servers = [
            topology.servers['web_dmz1'],
            topology.servers['web_dmz2']
        ]
        self.http_port = 80
        self.https_port = 443
        
        # Browsing statistics
        self.requests_made = 0
        self.pages_loaded = 0
    
    def _generate_request_params(self) -> Tuple[str, str, str, bool, List[str]]:
        """
        Generate web request parameters
        Returns: (client_ip, server_ip, url, is_internal, resource_urls)
        """
        client_ip = self.topology.get_random_workstation()
        
        # 40% internal browsing, 60% simulated external
        is_internal = random.random() < 0.4
        
        if is_internal:
            server_ip = random.choice(self.web_servers)
            url = random.choice(self.INTERNAL_URLS)
        else:
            # Simulated external - resolve through DNS
            server_ip = f"10.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            url = random.choice(self.EXTERNAL_URLS)
        
        # Generate additional resource requests (CSS, JS, images)
        num_resources = random.randint(3, 15)
        resource_urls = []
        
        for i in range(num_resources):
            resource_type = random.choice(['css', 'js', 'png', 'jpg', 'ico'])
            resource_urls.append(f"/static/assets/resource{i}.{resource_type}")
        
        return client_ip, server_ip, url, is_internal, resource_urls
    
    def _create_http_request(self, host: str, url: str, user_agent: str) -> bytes:
        """Create HTTP GET request"""
        request = f"GET {url} HTTP/1.1\r\n"
        request += f"Host: {host}\r\n"
        request += f"User-Agent: {user_agent}\r\n"
        request += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n"
        request += "Accept-Language: en-US,en;q=0.5\r\n"
        request += "Accept-Encoding: gzip, deflate\r\n"
        request += "Connection: keep-alive\r\n"
        request += "Upgrade-Insecure-Requests: 1\r\n"
        request += "\r\n"
        
        return request.encode()
    
    def _create_http_response(self, url: str, is_html: bool = True) -> bytes:
        """Create HTTP response"""
        if is_html:
            content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Enterprise Portal</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <h1>Welcome to Enterprise Portal</h1>
    <p>Page: {url}</p>
    <script src="/static/app.js"></script>
</body>
</html>"""
        else:
            # Static resource
            content = "/* CSS/JS/Image content */" * random.randint(10, 50)
        
        response = "HTTP/1.1 200 OK\r\n"
        response += "Content-Type: text/html; charset=utf-8\r\n" if is_html else "Content-Type: application/octet-stream\r\n"
        response += f"Content-Length: {len(content)}\r\n"
        response += "Connection: keep-alive\r\n"
        response += "Cache-Control: max-age=3600\r\n"
        response += "\r\n"
        response += content
        
        return response.encode()
    
    async def browse_page(self):
        """Simulate browsing a web page"""
        try:
            client_ip, server_ip, url, is_internal, resource_urls = self._generate_request_params()
            user_agent = random.choice(self.USER_AGENTS)
            
            # Choose port (80 for HTTP, 443 for HTTPS)
            use_https = random.random() < 0.7  # 70% HTTPS
            port = self.https_port if use_https else self.http_port
            protocol = "HTTPS" if use_https else "HTTP"
            
            # Determine host header
            if is_internal:
                host = "intranet.enterprise.local"
            else:
                host = f"www.external-site-{random.randint(1, 100)}.com"
            
            # Create socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            try:
                # Try to bind to client IP
                sock.bind((client_ip, 0))
            except OSError:
                logger.debug(f"Could not bind to {client_ip}, using default interface")
            
            try:
                # Attempt connection
                sock.settimeout(2)
                await asyncio.get_event_loop().sock_connect(sock, (server_ip, port))
                
                # Send main page request
                request = self._create_http_request(host, url, user_agent)
                await asyncio.get_event_loop().sock_sendall(sock, request)
                
                # Receive response
                response = await asyncio.get_event_loop().sock_recv(sock, 4096)
                
                self.requests_made += 1
                self.pages_loaded += 1
                
                logger.info(f"{protocol} Request: {client_ip} -> {server_ip}:{port} | "
                          f"URL: {host}{url}")
                
                # Simulate loading additional resources
                for resource_url in resource_urls[:5]:  # Limit to 5 resources
                    request = self._create_http_request(host, resource_url, user_agent)
                    await asyncio.get_event_loop().sock_sendall(sock, request)
                    await asyncio.sleep(0.01)  # Small delay between resource requests
                    self.requests_made += 1
                
            except (ConnectionRefusedError, OSError, asyncio.TimeoutError):
                # Server not running - just log the simulated traffic
                logger.debug(f"Simulated {protocol} request: {client_ip} -> {server_ip}:{port}")
                logger.debug(f"  URL: {host}{url}")
                logger.debug(f"  Resources: {len(resource_urls)}")
                
                self.requests_made += 1 + len(resource_urls[:5])
                self.pages_loaded += 1
            
            finally:
                sock.close()
            
            # Simulate user reading page
            await asyncio.sleep(random.uniform(1, 5))
                
        except Exception as e:
            logger.error(f"Error generating web traffic: {e}")
    
    async def run_server(self, server_ip: str):
        """Run a simple HTTP server (optional)"""
        try:
            server = await asyncio.start_server(
                self._handle_http_connection,
                server_ip,
                self.http_port
            )
            
            logger.info(f"HTTP server listening on {server_ip}:{self.http_port}")
            
            async with server:
                await server.serve_forever()
                
        except PermissionError:
            logger.warning("Cannot bind to port 80 (requires root). HTTP server will not start.")
        except Exception as e:
            logger.error(f"HTTP server error: {e}")
    
    async def _handle_http_connection(self, reader, writer):
        """Handle incoming HTTP connection"""
        addr = writer.get_extra_info('peername')
        logger.debug(f"HTTP connection from {addr[0]}")
        
        try:
            # Read request
            data = await reader.read(4096)
            if not data:
                return
            
            request = data.decode()
            lines = request.split('\r\n')
            
            if lines:
                request_line = lines[0]
                parts = request_line.split()
                
                if len(parts) >= 2:
                    method = parts[0]
                    url = parts[1]
                    
                    # Send response
                    is_html = not any(ext in url for ext in ['.css', '.js', '.png', '.jpg', '.ico'])
                    response = self._create_http_response(url, is_html)
                    writer.write(response)
                    await writer.drain()
        
        except Exception as e:
            logger.error(f"Error handling HTTP connection: {e}")
        finally:
            writer.close()
            await writer.wait_closed()
