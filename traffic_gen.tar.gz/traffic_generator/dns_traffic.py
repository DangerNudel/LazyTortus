#!/usr/bin/env python3
"""
DNS Traffic Generator
Provides DNS resolution for the isolated lab environment
"""

import asyncio
import logging
import random
import struct
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)


class DNSTrafficGenerator:
    """DNS server and query generator"""
    
    # Common domains to simulate internet access
    COMMON_DOMAINS = [
        'www.google.com', 'www.microsoft.com', 'www.amazon.com',
        'www.github.com', 'www.stackoverflow.com', 'www.reddit.com',
        'mail.google.com', 'outlook.office365.com', 'www.linkedin.com',
        'www.wikipedia.org', 'www.cnn.com', 'www.bbc.com',
        'update.microsoft.com', 'windowsupdate.microsoft.com',
        'api.github.com', 'registry.npmjs.org', 'pypi.org',
        'security.ubuntu.com', 'archive.ubuntu.com',
        'www.youtube.com', 'www.twitter.com', 'www.facebook.com'
    ]
    
    # Internal domains for the lab
    INTERNAL_DOMAINS = [
        'mail.enterprise.local', 'ftp.enterprise.local',
        'intranet.enterprise.local', 'files.enterprise.local',
        'wiki.enterprise.local', 'portal.enterprise.local',
        'hr.enterprise.local', 'finance.enterprise.local',
        'ops.enterprise.local', 'dc1.enterprise.local'
    ]
    
    def __init__(self, topology):
        self.topology = topology
        self.dns_server_ip = topology.servers['dns']
        
        # DNS response cache
        self.dns_cache: Dict[str, str] = {}
        self._initialize_cache()
        
        # Stats
        self.queries_received = 0
        self.queries_sent = 0
    
    def _initialize_cache(self):
        """Initialize DNS cache with mappings"""
        # Map internal domains to internal IPs
        internal_mappings = {
            'mail.enterprise.local': self.topology.servers['email'],
            'ftp.enterprise.local': self.topology.servers['ftp'],
            'intranet.enterprise.local': self.topology.servers['web_dmz1'],
            'files.enterprise.local': self.topology.servers['file_server'],
            'portal.enterprise.local': self.topology.servers['web_dmz2'],
            'dc1.enterprise.local': self.topology.servers['dns']
        }
        self.dns_cache.update(internal_mappings)
        
        # Map external domains to fake external IPs (10.0.0.0/8 range to simulate external)
        for domain in self.COMMON_DOMAINS:
            # Generate a fake "external" IP
            fake_ip = f"10.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            self.dns_cache[domain] = fake_ip
        
        logger.info(f"DNS cache initialized with {len(self.dns_cache)} entries")
    
    def _create_dns_query(self, domain: str, query_id: int) -> bytes:
        """Create a DNS query packet"""
        # DNS Header
        flags = 0x0100  # Standard query
        questions = 1
        answer_rrs = 0
        authority_rrs = 0
        additional_rrs = 0
        
        header = struct.pack('!HHHHHH', query_id, flags, questions, 
                            answer_rrs, authority_rrs, additional_rrs)
        
        # DNS Question
        question = b''
        for part in domain.split('.'):
            question += struct.pack('B', len(part)) + part.encode()
        question += b'\x00'  # Null terminator
        question += struct.pack('!HH', 1, 1)  # Type A, Class IN
        
        return header + question
    
    def _create_dns_response(self, query: bytes, domain: str, ip: str) -> bytes:
        """Create a DNS response packet"""
        # Parse query ID
        query_id = struct.unpack('!H', query[:2])[0]
        
        # DNS Header (response)
        flags = 0x8180  # Standard response, no error
        questions = 1
        answer_rrs = 1
        authority_rrs = 0
        additional_rrs = 0
        
        header = struct.pack('!HHHHHH', query_id, flags, questions,
                            answer_rrs, authority_rrs, additional_rrs)
        
        # DNS Question (echo from query)
        question = b''
        for part in domain.split('.'):
            question += struct.pack('B', len(part)) + part.encode()
        question += b'\x00'
        question += struct.pack('!HH', 1, 1)  # Type A, Class IN
        
        # DNS Answer
        # Name pointer to question
        answer = b'\xc0\x0c'
        # Type A, Class IN, TTL, Data length
        answer += struct.pack('!HHIH', 1, 1, 3600, 4)
        # IP address
        ip_parts = [int(x) for x in ip.split('.')]
        answer += struct.pack('!BBBB', *ip_parts)
        
        return header + question + answer
    
    async def run_server(self):
        """Run DNS server to respond to queries"""
        try:
            # Create UDP socket for DNS
            sock = asyncio.get_event_loop().create_datagram_endpoint(
                lambda: DNSServerProtocol(self),
                local_addr=(self.dns_server_ip, 53)
            )
            
            transport, protocol = await sock
            logger.info(f"DNS server listening on {self.dns_server_ip}:53")
            
            # Keep server running
            while True:
                await asyncio.sleep(1)
                
        except PermissionError:
            logger.warning("Cannot bind to port 53 (requires root). DNS server will not start.")
            logger.warning("Run with sudo or use a port >= 1024 for testing")
        except Exception as e:
            logger.error(f"DNS server error: {e}")
    
    async def query_domain(self):
        """Generate a DNS query from a random workstation"""
        try:
            source_ip = self.topology.get_random_workstation()
            
            # Choose a domain to query (mix of internal and external)
            if random.random() < 0.3:  # 30% internal domains
                domain = random.choice(self.INTERNAL_DOMAINS)
            else:  # 70% external domains
                domain = random.choice(self.COMMON_DOMAINS)
            
            # Create DNS query
            query_id = random.randint(1, 65535)
            query = self._create_dns_query(domain, query_id)
            
            # Simulate sending query (in real implementation, send UDP packet)
            logger.debug(f"DNS Query: {source_ip} -> {self.dns_server_ip} for {domain}")
            self.queries_sent += 1
            
            # Get response from cache
            if domain in self.dns_cache:
                resolved_ip = self.dns_cache[domain]
                response = self._create_dns_response(query, domain, resolved_ip)
                logger.debug(f"DNS Response: {domain} -> {resolved_ip}")
            else:
                logger.debug(f"DNS Query: {domain} not in cache, returning NXDOMAIN")
            
        except Exception as e:
            logger.error(f"Error generating DNS query: {e}")
    
    def resolve(self, domain: str) -> str:
        """Resolve a domain to an IP address"""
        if domain in self.dns_cache:
            return self.dns_cache[domain]
        
        # Generate a random IP for unknown domains
        fake_ip = f"10.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
        self.dns_cache[domain] = fake_ip
        return fake_ip


class DNSServerProtocol(asyncio.DatagramProtocol):
    """DNS server protocol handler"""
    
    def __init__(self, dns_generator):
        self.dns_generator = dns_generator
        self.transport = None
    
    def connection_made(self, transport):
        self.transport = transport
    
    def datagram_received(self, data, addr):
        """Handle incoming DNS queries"""
        try:
            # Parse query to extract domain name
            # Simple parsing - production would be more robust
            query_id = struct.unpack('!H', data[:2])[0]
            
            # Extract domain name (simplified)
            domain_parts = []
            pos = 12  # Skip header
            while pos < len(data):
                length = data[pos]
                if length == 0:
                    break
                pos += 1
                domain_parts.append(data[pos:pos+length].decode())
                pos += length
            
            domain = '.'.join(domain_parts)
            
            if domain:
                logger.debug(f"DNS query received from {addr[0]} for {domain}")
                self.dns_generator.queries_received += 1
                
                # Resolve and send response
                if domain in self.dns_generator.dns_cache:
                    ip = self.dns_generator.dns_cache[domain]
                    response = self.dns_generator._create_dns_response(data, domain, ip)
                    self.transport.sendto(response, addr)
                    logger.debug(f"DNS response sent: {domain} -> {ip}")
        
        except Exception as e:
            logger.error(f"Error handling DNS query: {e}")
