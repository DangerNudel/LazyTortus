const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// Configuration
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const SALT_ROUNDS = 10;

// Initialize Express app
const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Initialize SQLite database
const db = new sqlite3.Database('./bridge_control.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Database initialization
function initializeDatabase() {
    // Users table
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `, (err) => {
        if (err) {
            console.error('Error creating users table:', err);
        } else {
            // Create default admin user
            createDefaultUser();
        }
    });

    // Bridge state table
    db.run(`
        CREATE TABLE IF NOT EXISTS bridge_state (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bridge_id TEXT NOT NULL,
            status TEXT NOT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Activity log table
    db.run(`
        CREATE TABLE IF NOT EXISTS activity_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            bridge_id TEXT NOT NULL,
            action TEXT NOT NULL,
            status TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Initialize bridge states
    db.run(`INSERT OR IGNORE INTO bridge_state (id, bridge_id, status) VALUES (1, 'bridge1', 'lowered')`);
    db.run(`INSERT OR IGNORE INTO bridge_state (id, bridge_id, status) VALUES (2, 'bridge2', 'lowered')`);
}

// Create default admin user
async function createDefaultUser() {
    db.get('SELECT * FROM users WHERE username = ?', ['admin'], async (err, row) => {
        if (err) {
            console.error('Error checking for admin user:', err);
            return;
        }
        
        if (!row) {
            const hashedPassword = await bcrypt.hash('railroad123', SALT_ROUNDS);
            db.run(
                'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
                ['admin', hashedPassword, 'admin'],
                (err) => {
                    if (err) {
                        console.error('Error creating admin user:', err);
                    } else {
                        console.log('Default admin user created: admin/railroad123');
                    }
                }
            );
        }
    });
}

// Bridge state management
const bridgeState = {
    bridge1: 'lowered',
    bridge2: 'lowered'
};

// Load initial bridge state from database
function loadBridgeState() {
    db.all('SELECT bridge_id, status FROM bridge_state', [], (err, rows) => {
        if (err) {
            console.error('Error loading bridge state:', err);
            return;
        }
        rows.forEach(row => {
            bridgeState[row.bridge_id] = row.status;
        });
        console.log('Bridge state loaded:', bridgeState);
    });
}

loadBridgeState();

// WebSocket connection handling
const clients = new Set();

wss.on('connection', (ws) => {
    console.log('New WebSocket client connected');
    clients.add(ws);

    // Send current bridge state to new client
    ws.send(JSON.stringify({
        type: 'state_update',
        data: bridgeState
    }));

    ws.on('close', () => {
        console.log('WebSocket client disconnected');
        clients.delete(ws);
    });

    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        clients.delete(ws);
    });
});

// Broadcast to all connected clients
function broadcast(message) {
    const data = JSON.stringify(message);
    clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(data);
        }
    });
}

// JWT verification middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access token required' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
}

// Log activity to database
function logActivity(username, bridgeId, action, status) {
    db.run(
        'INSERT INTO activity_log (username, bridge_id, action, status) VALUES (?, ?, ?, ?)',
        [username, bridgeId, action, status],
        (err) => {
            if (err) {
                console.error('Error logging activity:', err);
            }
        }
    );
}

// Routes

// Login endpoint
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }

    db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const passwordMatch = await bcrypt.compare(password, user.password_hash);

        if (!passwordMatch) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { username: user.username, role: user.role },
            JWT_SECRET,
            { expiresIn: '24h' }
        );

        res.json({
            success: true,
            token,
            username: user.username,
            role: user.role
        });
    });
});

// Get bridge status
app.get('/api/status', authenticateToken, (req, res) => {
    res.json({
        success: true,
        bridges: bridgeState
    });
});

// Get specific bridge status
app.get('/api/status/:bridgeId', authenticateToken, (req, res) => {
    const { bridgeId } = req.params;

    if (!bridgeState.hasOwnProperty(bridgeId)) {
        return res.status(404).json({ error: 'Bridge not found' });
    }

    res.json({
        success: true,
        bridge: bridgeId,
        status: bridgeState[bridgeId]
    });
});

// Raise bridge
app.post('/api/raise/:bridgeId', authenticateToken, (req, res) => {
    const { bridgeId } = req.params;
    const { username } = req.user;

    if (!bridgeState.hasOwnProperty(bridgeId)) {
        return res.status(404).json({ error: 'Bridge not found' });
    }

    if (bridgeState[bridgeId] === 'raised') {
        return res.status(400).json({ 
            success: false,
            error: 'Bridge is already raised' 
        });
    }

    // Update state
    bridgeState[bridgeId] = 'raising';

    // Update database
    db.run(
        'UPDATE bridge_state SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE bridge_id = ?',
        ['raised', bridgeId]
    );

    // Log activity
    logActivity(username, bridgeId, 'raise', 'success');

    // Broadcast to all clients
    broadcast({
        type: 'bridge_update',
        bridge: bridgeId,
        status: 'raising',
        username
    });

    // Simulate bridge raising time (2 seconds)
    setTimeout(() => {
        bridgeState[bridgeId] = 'raised';
        broadcast({
            type: 'bridge_update',
            bridge: bridgeId,
            status: 'raised',
            username
        });
    }, 2000);

    res.json({
        success: true,
        message: `Bridge ${bridgeId} raising initiated`,
        bridge: bridgeId,
        status: 'raising'
    });
});

// Lower bridge
app.post('/api/lower/:bridgeId', authenticateToken, (req, res) => {
    const { bridgeId } = req.params;
    const { username } = req.user;

    if (!bridgeState.hasOwnProperty(bridgeId)) {
        return res.status(404).json({ error: 'Bridge not found' });
    }

    if (bridgeState[bridgeId] === 'lowered') {
        return res.status(400).json({ 
            success: false,
            error: 'Bridge is already lowered' 
        });
    }

    // Update state
    bridgeState[bridgeId] = 'lowering';

    // Update database
    db.run(
        'UPDATE bridge_state SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE bridge_id = ?',
        ['lowered', bridgeId]
    );

    // Log activity
    logActivity(username, bridgeId, 'lower', 'success');

    // Broadcast to all clients
    broadcast({
        type: 'bridge_update',
        bridge: bridgeId,
        status: 'lowering',
        username
    });

    // Simulate bridge lowering time (2 seconds)
    setTimeout(() => {
        bridgeState[bridgeId] = 'lowered';
        broadcast({
            type: 'bridge_update',
            bridge: bridgeId,
            status: 'lowered',
            username
        });
    }, 2000);

    res.json({
        success: true,
        message: `Bridge ${bridgeId} lowering initiated`,
        bridge: bridgeId,
        status: 'lowering'
    });
});

// Get activity log
app.get('/api/logs', authenticateToken, (req, res) => {
    const limit = parseInt(req.query.limit) || 50;

    db.all(
        'SELECT * FROM activity_log ORDER BY timestamp DESC LIMIT ?',
        [limit],
        (err, rows) => {
            if (err) {
                console.error('Error fetching logs:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            res.json({
                success: true,
                logs: rows
            });
        }
    );
});

// Create new user (admin only)
app.post('/api/users', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    const { username, password, role } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password required' });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    db.run(
        'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
        [username, hashedPassword, role || 'user'],
        (err) => {
            if (err) {
                if (err.message.includes('UNIQUE')) {
                    return res.status(409).json({ error: 'Username already exists' });
                }
                console.error('Error creating user:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            res.json({
                success: true,
                message: 'User created successfully'
            });
        }
    );
});

// Get all users (admin only)
app.get('/api/users', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    db.all(
        'SELECT id, username, role, created_at FROM users ORDER BY created_at DESC',
        [],
        (err, rows) => {
            if (err) {
                console.error('Error fetching users:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            res.json({
                success: true,
                users: rows
            });
        }
    );
});

// Get single user (admin only)
app.get('/api/users/:id', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    const { id } = req.params;

    db.get(
        'SELECT id, username, role, created_at FROM users WHERE id = ?',
        [id],
        (err, row) => {
            if (err) {
                console.error('Error fetching user:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            if (!row) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({
                success: true,
                user: row
            });
        }
    );
});

// Update user (admin only)
app.put('/api/users/:id', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    const { id } = req.params;
    const { username, password, role } = req.body;

    // Build dynamic update query
    const updates = [];
    const values = [];

    if (username) {
        updates.push('username = ?');
        values.push(username);
    }

    if (password) {
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        updates.push('password_hash = ?');
        values.push(hashedPassword);
    }

    if (role) {
        if (role !== 'admin' && role !== 'user') {
            return res.status(400).json({ error: 'Invalid role. Must be "admin" or "user"' });
        }
        updates.push('role = ?');
        values.push(role);
    }

    if (updates.length === 0) {
        return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(id);

    db.run(
        `UPDATE users SET ${updates.join(', ')} WHERE id = ?`,
        values,
        function(err) {
            if (err) {
                if (err.message.includes('UNIQUE')) {
                    return res.status(409).json({ error: 'Username already exists' });
                }
                console.error('Error updating user:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            if (this.changes === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({
                success: true,
                message: 'User updated successfully'
            });
        }
    );
});

// Delete user (admin only)
app.delete('/api/users/:id', authenticateToken, (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }

    const { id } = req.params;

    // Prevent deleting yourself
    db.get('SELECT username FROM users WHERE id = ?', [id], (err, user) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (user.username === req.user.username) {
            return res.status(400).json({ error: 'Cannot delete your own account' });
        }

        db.run('DELETE FROM users WHERE id = ?', [id], function(err) {
            if (err) {
                console.error('Error deleting user:', err);
                return res.status(500).json({ error: 'Internal server error' });
            }

            if (this.changes === 0) {
                return res.status(404).json({ error: 'User not found' });
            }

            res.json({
                success: true,
                message: 'User deleted successfully'
            });
        });
    });
});

// Change own password (any authenticated user)
app.put('/api/users/me/password', authenticateToken, async (req, res) => {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
        return res.status(400).json({ error: 'Current password and new password required' });
    }

    // Get current user
    db.get('SELECT * FROM users WHERE username = ?', [req.user.username], async (err, user) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).json({ error: 'Internal server error' });
        }

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Verify current password
        const passwordMatch = await bcrypt.compare(currentPassword, user.password_hash);

        if (!passwordMatch) {
            return res.status(401).json({ error: 'Current password is incorrect' });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);

        // Update password
        db.run(
            'UPDATE users SET password_hash = ? WHERE id = ?',
            [hashedPassword, user.id],
            function(err) {
                if (err) {
                    console.error('Error updating password:', err);
                    return res.status(500).json({ error: 'Internal server error' });
                }

                res.json({
                    success: true,
                    message: 'Password changed successfully'
                });
            }
        );
    });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok',
        timestamp: new Date().toISOString()
    });
});

// Serve the frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// Start server
server.listen(PORT, () => {
    console.log(`
╔═══════════════════════════════════════════════════════╗
║  Donovia DOT Railroad Bridge Control System Backend   ║
║  Server running on http://localhost:${PORT}           ║
║  WebSocket enabled for real-time updates              ║
║  Database: SQLite (bridge_control.db)                 ║
╚═══════════════════════════════════════════════════════╝
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM signal received: closing HTTP server');
    server.close(() => {
        console.log('HTTP server closed');
        db.close((err) => {
            if (err) {
                console.error('Error closing database:', err);
            } else {
                console.log('Database connection closed');
            }
            process.exit(0);
        });
    });
});
