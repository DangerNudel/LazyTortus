// Configuration
const API_BASE = window.location.origin;
const WS_URL = `ws://${window.location.host}`;

// State management
let authToken = null;
let currentUsername = null;
let ws = null;
let reconnectInterval = null;

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Check for existing token
    authToken = localStorage.getItem('authToken');
    currentUsername = localStorage.getItem('username');

    if (authToken) {
        // Verify token is still valid
        verifyToken();
    }

    setupEventListeners();
    updateTime();
    setInterval(updateTime, 1000);
});

// Setup event listeners
function setupEventListeners() {
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    document.getElementById('terminalInput').addEventListener('keydown', handleTerminalInput);

    // Keep terminal focused
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.login-container') && document.getElementById('mainInterface').classList.contains('active')) {
            document.getElementById('terminalInput').focus();
        }
    });
}

// Authentication
async function handleLogin(e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');
    const loginBtn = document.getElementById('loginBtn');

    loginBtn.disabled = true;
    loginBtn.textContent = 'AUTHENTICATING...';

    try {
        const response = await fetch(`${API_BASE}/api/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok && data.success) {
            authToken = data.token;
            currentUsername = data.username;
            
            localStorage.setItem('authToken', authToken);
            localStorage.setItem('username', currentUsername);
            localStorage.setItem('userRole', data.role);

            document.getElementById('loginScreen').classList.add('hidden');
            document.getElementById('mainInterface').classList.add('active');
            document.getElementById('currentUser').textContent = `USER: ${currentUsername.toUpperCase()}`;

            // Show admin button if user is admin
            if (data.role === 'admin') {
                document.getElementById('adminBtn').style.display = 'inline-block';
            }

            addTerminalLine(`User authenticated successfully.`, 'system');
            addTerminalLine(`Welcome, ${currentUsername.toUpperCase()}`, 'system');

            // Connect WebSocket
            connectWebSocket();

            // Load initial bridge state
            loadBridgeState();
        } else {
            errorMessage.textContent = `✕ ${data.error || 'Invalid credentials'}`;
            errorMessage.classList.add('show');
            setTimeout(() => errorMessage.classList.remove('show'), 3000);
        }
    } catch (error) {
        console.error('Login error:', error);
        errorMessage.textContent = '✕ Connection error. Please check if server is running.';
        errorMessage.classList.add('show');
        setTimeout(() => errorMessage.classList.remove('show'), 3000);
    } finally {
        loginBtn.disabled = false;
        loginBtn.textContent = 'ACCESS SYSTEM';
    }
}

async function verifyToken() {
    try {
        const response = await fetch(`${API_BASE}/api/status`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            document.getElementById('loginScreen').classList.add('hidden');
            document.getElementById('mainInterface').classList.add('active');
            document.getElementById('currentUser').textContent = `USER: ${currentUsername.toUpperCase()}`;
            
            // Show admin button if user is admin
            const userRole = localStorage.getItem('userRole');
            if (userRole === 'admin') {
                document.getElementById('adminBtn').style.display = 'inline-block';
            }
            
            connectWebSocket();
            loadBridgeState();
        } else {
            // Token invalid, clear storage
            localStorage.removeItem('authToken');
            localStorage.removeItem('username');
            authToken = null;
            currentUsername = null;
        }
    } catch (error) {
        console.error('Token verification error:', error);
    }
}

function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
        localStorage.removeItem('userRole');
        authToken = null;
        currentUsername = null;

        if (ws) {
            ws.close();
        }

        document.getElementById('loginScreen').classList.remove('hidden');
        document.getElementById('mainInterface').classList.remove('active');
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
        
        resetTerminal();
    }
}

// WebSocket connection
function connectWebSocket() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        return;
    }

    try {
        ws = new WebSocket(WS_URL);

        ws.onopen = () => {
            console.log('WebSocket connected');
            updateConnectionStatus(true);
            addTerminalLine('Real-time connection established.', 'system');
            
            if (reconnectInterval) {
                clearInterval(reconnectInterval);
                reconnectInterval = null;
            }
        };

        ws.onmessage = (event) => {
            try {
                const message = JSON.parse(event.data);
                handleWebSocketMessage(message);
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
            }
        };

        ws.onclose = () => {
            console.log('WebSocket disconnected');
            updateConnectionStatus(false);
            addTerminalLine('Real-time connection lost. Attempting to reconnect...', 'warning');
            
            // Attempt to reconnect
            if (!reconnectInterval) {
                reconnectInterval = setInterval(() => {
                    if (authToken) {
                        connectWebSocket();
                    }
                }, 5000);
            }
        };

        ws.onerror = (error) => {
            console.error('WebSocket error:', error);
        };
    } catch (error) {
        console.error('Error creating WebSocket:', error);
        updateConnectionStatus(false);
    }
}

function handleWebSocketMessage(message) {
    switch (message.type) {
        case 'state_update':
            // Initial state update
            updateBridgeUI('bridge1', message.data.bridge1);
            updateBridgeUI('bridge2', message.data.bridge2);
            break;

        case 'bridge_update':
            // Real-time bridge update
            updateBridgeUI(message.bridge, message.status);
            if (message.username !== currentUsername) {
                addTerminalLine(`Bridge ${message.bridge} ${message.status} by user: ${message.username}`, 'info');
            }
            break;
    }
}

function updateConnectionStatus(connected) {
    const statusDot = document.getElementById('connectionStatus');
    const statusText = document.getElementById('connectionText');

    if (connected) {
        statusDot.classList.remove('disconnected');
        statusText.textContent = 'SYSTEM ONLINE';
    } else {
        statusDot.classList.add('disconnected');
        statusText.textContent = 'DISCONNECTED';
    }
}

// API calls
async function loadBridgeState() {
    try {
        const response = await fetch(`${API_BASE}/api/status`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateBridgeUI('bridge1', data.bridges.bridge1);
            updateBridgeUI('bridge2', data.bridges.bridge2);
        }
    } catch (error) {
        console.error('Error loading bridge state:', error);
        addTerminalLine('Error loading bridge state from server.', 'error');
    }
}

async function raiseBridge(bridgeId) {
    try {
        addTerminalLine(`Initiating raise sequence for ${bridgeId}...`, 'system');
        addTerminalLine(`Checking safety sensors...`, 'info');

        const response = await fetch(`${API_BASE}/api/raise/${bridgeId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (response.ok && data.success) {
            addTerminalLine(`Safety check passed. Activating hydraulics...`, 'system');
            addTerminalLine(`${data.message}`, 'system');
        } else {
            addTerminalLine(`Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error raising bridge:', error);
        addTerminalLine(`Error communicating with server.`, 'error');
    }
}

async function lowerBridge(bridgeId) {
    try {
        addTerminalLine(`Initiating lower sequence for ${bridgeId}...`, 'system');
        addTerminalLine(`Checking clearance...`, 'info');

        const response = await fetch(`${API_BASE}/api/lower/${bridgeId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (response.ok && data.success) {
            addTerminalLine(`Clearance confirmed. Releasing hydraulics...`, 'system');
            addTerminalLine(`${data.message}`, 'system');
        } else {
            addTerminalLine(`Error: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Error lowering bridge:', error);
        addTerminalLine(`Error communicating with server.`, 'error');
    }
}

async function showStatus(bridgeId = null) {
    try {
        const url = bridgeId 
            ? `${API_BASE}/api/status/${bridgeId}`
            : `${API_BASE}/api/status`;

        const response = await fetch(url, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();

            if (bridgeId) {
                const location = bridgeId === 'bridge1' ? 'Laurens, SC' : 'Columbia, SC';
                addTerminalLine(`─── ${bridgeId} Status ───`, 'info');
                addTerminalLine(`Location: ${location}`, 'info');
                addTerminalLine(`Status: ${data.status.toUpperCase()}`, 'system');
                addTerminalLine(`────────────────────────`, 'info');
            } else {
                addTerminalLine(`─── System Status ───`, 'info');
                addTerminalLine(`Bridge 1 (Laurens): ${data.bridges.bridge1.toUpperCase()}`, 'system');
                addTerminalLine(`Bridge 2 (Columbia): ${data.bridges.bridge2.toUpperCase()}`, 'system');
                addTerminalLine(`System: ONLINE`, 'system');
                addTerminalLine(`────────────────────`, 'info');
            }
        }
    } catch (error) {
        console.error('Error getting status:', error);
        addTerminalLine(`Error getting status from server.`, 'error');
    }
}

// UI updates
function updateBridgeUI(bridgeId, status) {
    const bridgeNum = bridgeId.replace('bridge', '');
    const deck = document.getElementById(`${bridgeId}Deck`);
    const statusElement = document.getElementById(`${bridgeId}Status`);
    const statusBadge = statusElement.querySelector('.status-badge');

    // Remove all status classes
    statusElement.classList.remove('raised', 'lowered', 'raising', 'lowering');
    deck.classList.remove('raised');

    // Add appropriate class
    statusElement.classList.add(status);

    switch (status) {
        case 'raised':
            deck.classList.add('raised');
            statusBadge.textContent = 'RAISED';
            break;
        case 'raising':
            deck.classList.add('raised');
            statusBadge.textContent = 'RAISING...';
            break;
        case 'lowering':
            statusBadge.textContent = 'LOWERING...';
            break;
        case 'lowered':
        default:
            statusBadge.textContent = 'LOWERED';
            break;
    }
}

// Terminal
function handleTerminalInput(e) {
    if (e.key === 'Enter') {
        const command = e.target.value.trim().toLowerCase();

        if (command) {
            addTerminalLine(`root@ddot:~$ ${command}`, 'info');

            switch (command) {
                case 'raise bridge1':
                    raiseBridge('bridge1');
                    break;
                case 'lower bridge1':
                    lowerBridge('bridge1');
                    break;
                case 'raise bridge2':
                    raiseBridge('bridge2');
                    break;
                case 'lower bridge2':
                    lowerBridge('bridge2');
                    break;
                case 'status':
                    showStatus();
                    break;
                case 'status bridge1':
                    showStatus('bridge1');
                    break;
                case 'status bridge2':
                    showStatus('bridge2');
                    break;
                case 'help':
                    showHelp();
                    break;
                case 'clear':
                    document.getElementById('terminalOutput').innerHTML = '';
                    break;
                default:
                    addTerminalLine(`Command not found: ${command}`, 'error');
                    addTerminalLine(`Type 'help' for available commands.`, 'info');
            }
        }

        e.target.value = '';
    }
}

function addTerminalLine(text, type = 'info') {
    const terminalOutput = document.getElementById('terminalOutput');
    const line = document.createElement('div');
    line.className = `terminal-line ${type}`;
    line.textContent = text;
    terminalOutput.appendChild(line);
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
}

function showHelp() {
    addTerminalLine(`─── Available Commands ───`, 'info');
    addTerminalLine(`raise bridge1     - Raise Bridge 1 (Laurens)`, 'info');
    addTerminalLine(`lower bridge1     - Lower Bridge 1 (Laurens)`, 'info');
    addTerminalLine(`raise bridge2     - Raise Bridge 2 (Columbia)`, 'info');
    addTerminalLine(`lower bridge2     - Lower Bridge 2 (Columbia)`, 'info');
    addTerminalLine(`status            - Display system status`, 'info');
    addTerminalLine(`status bridge1    - Display Bridge 1 status`, 'info');
    addTerminalLine(`status bridge2    - Display Bridge 2 status`, 'info');
    addTerminalLine(`help              - Display this help message`, 'info');
    addTerminalLine(`clear             - Clear terminal output`, 'info');
    addTerminalLine(`─────────────────────────`, 'info');
}

function resetTerminal() {
    document.getElementById('terminalOutput').innerHTML = `
        <div class="terminal-line system">Donovia DOT Railroad Bridge Control System v2.4.1</div>
        <div class="terminal-line system">Ubuntu 24.04 LTS - Kernel 6.8.0-49-generic</div>
        <div class="terminal-line info">System initialized. Type 'help' for available commands.</div>
        <div class="terminal-line info">──────────────────────────────────────────────────────</div>
    `;
}

// Time updates
function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour12: false });
    const dateString = now.toLocaleDateString('en-US');
    
    const currentTimeEl = document.getElementById('currentTime');
    if (currentTimeEl) {
        currentTimeEl.textContent = `${dateString} ${timeString}`;
    }

    const timestamp = now.toLocaleTimeString('en-US', { hour12: false });
    const timestamp1 = document.getElementById('timestamp1');
    const timestamp2 = document.getElementById('timestamp2');
    
    if (timestamp1) timestamp1.textContent = timestamp;
    if (timestamp2) timestamp2.textContent = timestamp;
}
