// Configuration
const API_BASE = window.location.origin;

// State
let authToken = null;
let currentUsername = null;
let allUsers = [];
let userToDelete = null;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    authToken = localStorage.getItem('authToken');
    currentUsername = localStorage.getItem('username');

    if (!authToken) {
        window.location.href = '/';
        return;
    }

    // Verify admin access
    verifyAdminAccess();

    // Setup event listeners
    setupEventListeners();
});

// Verify admin access
async function verifyAdminAccess() {
    try {
        const response = await fetch(`${API_BASE}/api/users`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.status === 403) {
            showMessage('Access denied. Admin privileges required.', 'error');
            setTimeout(() => {
                window.location.href = '/';
            }, 2000);
            return;
        }

        if (response.ok) {
            document.getElementById('currentUser').textContent = `USER: ${currentUsername.toUpperCase()}`;
            loadUsers();
        } else {
            localStorage.removeItem('authToken');
            localStorage.removeItem('username');
            window.location.href = '/';
        }
    } catch (error) {
        console.error('Error verifying admin access:', error);
        showMessage('Connection error', 'error');
    }
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('logoutBtn').addEventListener('click', logout);
    document.getElementById('addUserBtn').addEventListener('click', () => openModal());
    document.getElementById('closeModal').addEventListener('click', closeModal);
    document.getElementById('cancelBtn').addEventListener('click', closeModal);
    document.getElementById('userForm').addEventListener('submit', saveUser);
    document.getElementById('searchInput').addEventListener('input', filterUsers);
    document.getElementById('closeDeleteModal').addEventListener('click', closeDeleteModal);
    document.getElementById('cancelDeleteBtn').addEventListener('click', closeDeleteModal);
    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete);

    // Close modal on outside click
    document.getElementById('userModal').addEventListener('click', (e) => {
        if (e.target.id === 'userModal') {
            closeModal();
        }
    });

    document.getElementById('deleteModal').addEventListener('click', (e) => {
        if (e.target.id === 'deleteModal') {
            closeDeleteModal();
        }
    });
}

// Load users
async function loadUsers() {
    try {
        const response = await fetch(`${API_BASE}/api/users`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            allUsers = data.users;
            renderUsers(allUsers);
        } else {
            showMessage('Failed to load users', 'error');
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showMessage('Connection error', 'error');
    }
}

// Render users table
function renderUsers(users) {
    const tbody = document.getElementById('usersTableBody');

    if (users.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="empty-state">
                    <h3>No users found</h3>
                    <p>Click "Add New User" to create your first user</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.username}</td>
            <td><span class="role-badge ${user.role}">${user.role.toUpperCase()}</span></td>
            <td>${formatDate(user.created_at)}</td>
            <td>
                <div class="action-buttons">
                    <button class="icon-btn" onclick="editUser(${user.id})" title="Edit">✎ Edit</button>
                    <button class="icon-btn danger" onclick="deleteUser(${user.id}, '${user.username}')" title="Delete" ${user.username === currentUsername ? 'disabled' : ''}>✕ Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Filter users
function filterUsers() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allUsers.filter(user => 
        user.username.toLowerCase().includes(searchTerm) ||
        user.role.toLowerCase().includes(searchTerm)
    );
    renderUsers(filtered);
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Open modal
function openModal(userId = null) {
    const modal = document.getElementById('userModal');
    const form = document.getElementById('userForm');
    const modalTitle = document.getElementById('modalTitle');
    const passwordOptional = document.getElementById('passwordOptional');
    const passwordField = document.getElementById('password');

    form.reset();

    if (userId) {
        modalTitle.textContent = 'Edit User';
        passwordOptional.style.display = 'inline';
        passwordField.required = false;
        loadUserData(userId);
    } else {
        modalTitle.textContent = 'Add New User';
        passwordOptional.style.display = 'none';
        passwordField.required = true;
        document.getElementById('userId').value = '';
    }

    modal.classList.add('active');
}

// Close modal
function closeModal() {
    document.getElementById('userModal').classList.remove('active');
    document.getElementById('userForm').reset();
}

// Load user data for editing
async function loadUserData(userId) {
    try {
        const response = await fetch(`${API_BASE}/api/users/${userId}`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            const user = data.user;
            document.getElementById('userId').value = user.id;
            document.getElementById('username').value = user.username;
            document.getElementById('role').value = user.role;
        } else {
            showMessage('Failed to load user data', 'error');
        }
    } catch (error) {
        console.error('Error loading user:', error);
        showMessage('Connection error', 'error');
    }
}

// Save user
async function saveUser(e) {
    e.preventDefault();

    const userId = document.getElementById('userId').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    const saveBtn = document.getElementById('saveBtn');
    saveBtn.disabled = true;
    saveBtn.textContent = 'SAVING...';

    try {
        let url, method, body;

        if (userId) {
            // Update existing user
            url = `${API_BASE}/api/users/${userId}`;
            method = 'PUT';
            body = { username, role };
            if (password) {
                body.password = password;
            }
        } else {
            // Create new user
            url = `${API_BASE}/api/users`;
            method = 'POST';
            body = { username, password, role };
        }

        const response = await fetch(url, {
            method,
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(body)
        });

        const data = await response.json();

        if (response.ok) {
            showMessage(data.message, 'success');
            closeModal();
            loadUsers();
        } else {
            showMessage(data.error || 'Failed to save user', 'error');
        }
    } catch (error) {
        console.error('Error saving user:', error);
        showMessage('Connection error', 'error');
    } finally {
        saveBtn.disabled = false;
        saveBtn.textContent = 'SAVE USER';
    }
}

// Edit user (global function)
window.editUser = function(userId) {
    openModal(userId);
};

// Delete user (global function)
window.deleteUser = function(userId, username) {
    if (username === currentUsername) {
        showMessage('Cannot delete your own account', 'error');
        return;
    }

    userToDelete = userId;
    document.getElementById('deleteUsername').textContent = username;
    document.getElementById('deleteModal').classList.add('active');
};

// Close delete modal
function closeDeleteModal() {
    document.getElementById('deleteModal').classList.remove('active');
    userToDelete = null;
}

// Confirm delete
async function confirmDelete() {
    if (!userToDelete) return;

    const confirmBtn = document.getElementById('confirmDeleteBtn');
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'DELETING...';

    try {
        const response = await fetch(`${API_BASE}/api/users/${userToDelete}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            showMessage(data.message, 'success');
            closeDeleteModal();
            loadUsers();
        } else {
            showMessage(data.error || 'Failed to delete user', 'error');
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showMessage('Connection error', 'error');
    } finally {
        confirmBtn.disabled = false;
        confirmBtn.textContent = 'DELETE USER';
    }
}

// Logout
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
        window.location.href = '/';
    }
}

// Show message
function showMessage(text, type) {
    const container = document.getElementById('messageContainer');
    const message = document.createElement('div');
    message.className = `message ${type}`;
    message.textContent = text;
    container.appendChild(message);

    setTimeout(() => {
        message.remove();
    }, 5000);
}
