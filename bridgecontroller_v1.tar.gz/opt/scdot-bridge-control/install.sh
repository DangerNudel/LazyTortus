#!/bin/bash

# SCDOT Railroad Bridge Control System - Installation Script
# For Ubuntu 24.04 LTS

set -e

echo "╔═══════════════════════════════════════════════════════╗"
echo "║  SCDOT Railroad Bridge Control System Installer      ║"
echo "║  Version 2.4.1                                        ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "❌ Please run this script with sudo"
    exit 1
fi

# Install directory
INSTALL_DIR="/opt/scdot-bridge-control"

echo "📦 Installing system dependencies..."
apt update
apt install -y nodejs npm nginx

echo ""
echo "📁 Creating installation directory: $INSTALL_DIR"
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR

# Check if files exist in current directory
if [ ! -f "server.js" ] || [ ! -f "package.json" ]; then
    echo "❌ Error: server.js and package.json not found in current directory"
    echo "Please run this script from the application directory"
    exit 1
fi

echo ""
echo "📦 Installing Node.js dependencies..."
npm install

echo ""
echo "🔐 Generating secure JWT secret..."
JWT_SECRET=$(openssl rand -base64 32)

echo ""
echo "📝 Creating .env file..."
cat > .env << EOF
PORT=3000
JWT_SECRET=$JWT_SECRET
NODE_ENV=production
EOF

echo ""
echo "🔧 Setting up systemd service..."
cat > /etc/systemd/system/scdot-bridge.service << EOF
[Unit]
Description=SCDOT Railroad Bridge Control System
After=network.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

echo ""
echo "🔒 Setting permissions..."
chown -R www-data:www-data $INSTALL_DIR
chmod -R 755 $INSTALL_DIR

echo ""
echo "🔥 Configuring firewall..."
if command -v ufw &> /dev/null; then
    ufw allow 3000/tcp
    echo "✅ Firewall rule added for port 3000"
else
    echo "⚠️  UFW not installed, skipping firewall configuration"
fi

echo ""
echo "🚀 Starting service..."
systemctl daemon-reload
systemctl enable scdot-bridge.service
systemctl start scdot-bridge.service

echo ""
echo "✅ Installation complete!"
echo ""
echo "╔═══════════════════════════════════════════════════════╗"
echo "║  Service Information                                  ║"
echo "╚═══════════════════════════════════════════════════════╝"
echo ""
echo "🌐 Web Interface: http://localhost:3000"
echo "👤 Default Username: admin"
echo "🔑 Default Password: railroad123"
echo ""
echo "⚠️  IMPORTANT: Change the default password immediately!"
echo ""
echo "Service Commands:"
echo "  sudo systemctl status scdot-bridge   - Check status"
echo "  sudo systemctl restart scdot-bridge  - Restart service"
echo "  sudo systemctl stop scdot-bridge     - Stop service"
echo "  sudo journalctl -u scdot-bridge -f  - View logs"
echo ""
echo "📚 For more information, see README.md"
echo ""